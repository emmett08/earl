This freeze made zero provider calls. Its runner failed the material, schedule and post-provider accounting audit. Never execute it; create a fresh freeze with the corrected runner.
