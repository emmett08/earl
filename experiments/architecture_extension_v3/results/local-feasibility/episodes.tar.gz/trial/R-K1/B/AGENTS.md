# Coding session

Read FEATURE.md for the current requirement. Read architecture-context.json if present for the current-source assessment. Keep these host files unchanged.
