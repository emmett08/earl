"""An executable baseline for the architecture continuation experiment."""

from .domain import (
    Allocation, CancellationReceipt, Charge, CheckoutRequest, CompensationFailure, DispatchFailure, Event,
    FulfilmentError, IdempotencyConflict, Order, OutOfStock, Quote, QuotedLine, RefundUnresolved,
    RequestedLine, Reservation, ReturnLine, ReturnReceipt, Shipment,
)
from .memory import (
    InMemoryEventSink, InMemoryOrderStore, InMemoryPayments, InMemoryPricing,
    InMemoryShipping, InMemoryStock,
)
from .service import CheckoutService

__all__ = [
    "Allocation", "CancellationReceipt", "Charge", "CheckoutRequest", "CheckoutService", "CompensationFailure", "DispatchFailure",
    "Event", "FulfilmentError", "IdempotencyConflict", "InMemoryEventSink",
    "InMemoryOrderStore", "InMemoryPayments", "InMemoryPricing", "InMemoryShipping",
    "InMemoryStock", "Order", "OutOfStock", "Quote", "QuotedLine", "RequestedLine",
    "Reservation", "ReturnLine", "ReturnReceipt", "RefundUnresolved", "Shipment",
]
