import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, CompensationFailure, IdempotencyConflict,
    InMemoryEventSink, InMemoryOrderStore, InMemoryPayments, InMemoryPricing,
    InMemoryShipping, InMemoryStock, RefundUnresolved, RequestedLine, ReturnLine,
)


class RefundReconciliationTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock({"x": 2})
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(InMemoryPricing({"x": Decimal("10.00")}),
                                       self.stock, self.payments, self.shipping,
                                       self.orders, self.events)
        self.request = CheckoutRequest("purchase", "customer", (RequestedLine("x", 2),),
                                       "address", "token")

    def test_provider_records_once_then_loses_acknowledgement(self):
        charge = self.payments.capture(Decimal("12.00"), "GBP", "token", "capture")
        self.assertEqual(self.payments.refund_status("refund"), "not_applied")
        self.payments.fail_after_refund = True
        with self.assertRaises(RuntimeError):
            self.payments.refund(charge, Decimal("5.00"), "refund")
        self.assertEqual(self.payments.refund_status("refund"), "applied")
        self.payments.refund(charge, Decimal("5.00"), "refund")
        self.assertEqual(self.payments.refunded[charge.charge_id], Decimal("5.00"))
        self.payments.unknown_refund_keys.add("refund")
        self.assertEqual(self.payments.refund_status("refund"), "unknown")

    def test_return_unknown_blocks_completion_and_cancellation(self):
        order = self.service.checkout(self.request)
        lines = (ReturnLine(order.shipments[0].shipment_id, "x", 1),)
        self.payments.fail_after_refund = True
        with self.assertRaises(RuntimeError):
            self.service.return_items("purchase", "return", lines)
        key = "return:return"
        self.payments.unknown_refund_keys.add(key)
        with self.assertRaises(RefundUnresolved):
            self.service.return_items("purchase", "return", lines)
        with self.assertRaises(ValueError):
            self.service.cancel_order("purchase", "cancel")
        with self.assertRaises(ValueError):
            self.service.return_items("purchase", "conflicting", lines)
        self.assertEqual(len(self.events.events), 1)
        self.assertEqual(self.stock.on_hand["x"], 0)
        self.payments.unknown_refund_keys.remove(key)
        receipt = self.service.return_items("purchase", "return", lines)
        self.assertEqual(receipt.refunded_amount, Decimal("12.00"))
        self.assertEqual(self.stock.on_hand["x"], 1)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(len(self.events.events), 2)

    def test_cancellation_reconciles_after_ack_loss(self):
        order = self.service.checkout(self.request)
        self.payments.fail_after_refund = True
        with self.assertRaises(RuntimeError):
            self.service.cancel_order("purchase", "cancel")
        self.payments.unknown_refund_keys.add("cancel:cancel")
        with self.assertRaises(RefundUnresolved):
            self.service.cancel_order("purchase", "cancel")
        with self.assertRaises(IdempotencyConflict):
            self.service.cancel_order("purchase", "different")
        self.assertEqual(len(self.events.events), 1)
        self.payments.unknown_refund_keys.clear()
        self.service.cancel_order("purchase", "cancel")
        self.assertEqual(self.payments.refunded[order.charge.charge_id], order.charge.amount)
        self.assertEqual(self.stock.on_hand["x"], 2)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(len(self.events.events), 2)

    def test_checkout_rollback_reconciles_before_new_attempt(self):
        self.shipping.fail_dispatch = True
        self.payments.fail_after_refund = True
        with self.assertRaises(CompensationFailure):
            self.service.checkout(self.request)
        key = "purchase:attempt:1:rollback"
        self.assertEqual(self.payments.refund_status(key), "applied")
        self.payments.unknown_refund_keys.add(key)
        with self.assertRaises(RefundUnresolved):
            self.service.checkout(self.request)
        with self.assertRaises(IdempotencyConflict):
            self.service.checkout(CheckoutRequest("purchase", "other", self.request.lines,
                                                  "address", "token"))
        self.assertEqual(self.orders.attempts["purchase"], 1)
        self.assertFalse(self.events.events)
        self.payments.unknown_refund_keys.clear()
        self.shipping.fail_dispatch = False
        order = self.service.checkout(self.request)
        self.assertIn("attempt:2", order.charge.charge_id)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(self.payments.refunded[order.charge.charge_id], Decimal("0.00"))

    def test_not_applied_rollback_retries_same_key(self):
        self.shipping.fail_dispatch = True
        self.payments.fail_refund = True
        with self.assertRaises(CompensationFailure):
            self.service.checkout(self.request)
        self.assertEqual(self.payments.refund_status("purchase:attempt:1:rollback"), "not_applied")
        self.payments.fail_refund = False
        self.shipping.fail_dispatch = False
        self.service.checkout(self.request)
        self.assertIn("purchase:attempt:1:rollback", self.payments.refunds)
        self.assertEqual(len(self.payments.refunds), 1)


if __name__ == "__main__":
    unittest.main()
