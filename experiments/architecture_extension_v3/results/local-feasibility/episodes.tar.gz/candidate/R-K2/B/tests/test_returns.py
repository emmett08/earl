import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, IdempotencyConflict, InMemoryEventSink,
    InMemoryOrderStore, InMemoryPayments, InMemoryPricing, InMemoryShipping,
    InMemoryStock, RequestedLine, ReturnLine,
)


class ReturnTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock({"north": {"x": 2}, "south": {"x": 1}}, priorities=("north", "south"))
        self.payments = InMemoryPayments()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(InMemoryPricing({"x": Decimal("10.00")}), self.stock,
                                       self.payments, InMemoryShipping(), self.orders, self.events)
        self.order = self.service.checkout(CheckoutRequest(
            "order-1", "customer", (RequestedLine("x", 3),), "address", "token"))
        self.north, self.south = self.order.shipments
        self.lines = (ReturnLine(self.north.shipment_id, "x", 1),
                      ReturnLine(self.south.shipment_id, "x", 1))

    def test_split_return_and_replay(self):
        receipt = self.service.return_items("order-1", "return-1", self.lines)
        self.assertEqual(receipt.refunded_amount, Decimal("24.00"))
        self.assertEqual(self.stock.on_hand, {"north": {"x": 1}, "south": {"x": 1}})
        self.assertEqual(self.payments.refunded[self.order.charge.charge_id], Decimal("24.00"))
        self.assertEqual(self.service.return_items("order-1", "return-1", self.lines), receipt)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(self.order, self.orders.get("order-1"))
        self.assertEqual(len(self.events.events), 2)
        with self.assertRaises(IdempotencyConflict):
            self.service.return_items("order-1", "return-1", (self.lines[0],))

    def test_rejections_have_no_effect(self):
        invalid = [
            ("missing", self.lines),
            ("order-1", (ReturnLine("missing", "x", 1),)),
            ("order-1", (ReturnLine(self.north.shipment_id, "other", 1),)),
            ("order-1", (ReturnLine(self.north.shipment_id, "x", 0),)),
            ("order-1", (ReturnLine(self.north.shipment_id, "x", 2), self.lines[0])),
        ]
        for order_id, lines in invalid:
            with self.assertRaises(ValueError):
                self.service.return_items(order_id, "bad", lines)
        self.assertEqual(self.orders.return_intents, {})
        self.assertEqual(self.stock.on_hand["north"]["x"], 0)
        self.assertFalse(self.payments.refunds)

    def test_failure_boundaries_and_event_retry(self):
        self.payments.fail_refund = True
        with self.assertRaises(RuntimeError):
            self.service.return_items("order-1", "return-1", self.lines)
        self.assertFalse(self.orders.returns)
        self.assertEqual(self.stock.on_hand["north"]["x"], 0)
        self.payments.fail_refund = False
        self.orders.fail_save_return = True
        with self.assertRaises(RuntimeError):
            self.service.return_items("order-1", "return-1", self.lines)
        self.assertEqual(self.payments.refunded[self.order.charge.charge_id], Decimal("24.00"))
        self.assertEqual(self.stock.on_hand["north"]["x"], 1)
        self.orders.fail_save_return = False
        self.events.fail_publish = True
        self.service.return_items("order-1", "return-1", self.lines)
        self.assertEqual(len(self.orders.pending_events()), 1)
        self.events.fail_publish = False
        self.service.return_items("order-1", "return-1", self.lines)
        self.assertFalse(self.orders.pending_events())
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(self.stock.on_hand["north"]["x"], 1)


if __name__ == "__main__":
    unittest.main()
