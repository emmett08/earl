import json
import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, IdempotencyConflict, InMemoryEventSink,
    InMemoryOrderStore, InMemoryPayments, InMemoryPricing, InMemoryShipping,
    InMemoryStock, RequestedLine, ReturnLine,
)


class CancellationTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock({"north": {"x": 2}, "south": {"x": 1}},
                                   priorities=("north", "south"))
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(InMemoryPricing({"x": Decimal("10.00")}),
                                       self.stock, self.payments, self.shipping,
                                       self.orders, self.events)
        self.order = self.service.checkout(CheckoutRequest(
            "purchase", "customer", (RequestedLine("x", 3),), "address", "token"))

    def test_partial_return_then_cancel_retains_history_and_replays(self):
        north, south = self.order.shipments
        returned = (ReturnLine(north.shipment_id, "x", 1),)
        self.service.return_items("purchase", "return", returned)
        receipt = self.service.cancel_order("purchase", "cancel")
        self.assertEqual(receipt.cancellation_request_id, "cancel")
        self.assertEqual(receipt.refunded_amount, Decimal("24.00"))
        self.assertEqual(self.payments.refunded[self.order.charge.charge_id], Decimal("36.00"))
        self.assertEqual(self.stock.on_hand, {"north": {"x": 2}, "south": {"x": 1}})
        saved = self.orders.get("purchase")
        self.assertEqual(saved.status, "cancelled")
        self.assertEqual(saved.shipments, self.order.shipments)
        self.assertEqual(saved.reservation, self.order.reservation)
        self.assertIn("return", self.orders.returns)
        event = [e for e in self.events.events.values() if e.name == "OrderCancelled"][0]
        self.assertEqual(json.loads(dict(event.data)["allocations"]), [
            {"warehouse_id": "north", "sku": "x", "quantity": 1},
            {"warehouse_id": "south", "sku": "x", "quantity": 1},
        ])
        self.assertEqual(self.service.cancel_order("purchase", "cancel"), receipt)
        self.assertEqual(self.shipping.cancel_attempts, 2)
        self.assertEqual(len(self.payments.refunds), 2)
        self.assertEqual(len(self.stock.restorations), 2)
        self.assertEqual(self.service.return_items("purchase", "return", returned).refunded_amount,
                         Decimal("12.00"))
        with self.assertRaises(ValueError):
            self.service.return_items("purchase", "new-return", returned)
        with self.assertRaises(IdempotencyConflict):
            self.service.cancel_order("purchase", "other-cancel")
        other = self.service.checkout(CheckoutRequest(
            "second", "customer", (RequestedLine("x", 1),), "address", "token"))
        with self.assertRaises(IdempotencyConflict):
            self.service.cancel_order(other.request_id, "cancel")
        self.assertEqual(self.orders.get("second").status, "dispatched")
        with self.assertRaises(ValueError):
            self.service.cancel_order("unknown", "new")

    def test_second_carrier_failure_resumes_without_repeating_first(self):
        self.shipping.fail_on_cancel_number = 2
        with self.assertRaises(RuntimeError):
            self.service.cancel_order("purchase", "cancel")
        self.assertEqual(len(self.shipping.cancelled), 1)
        self.assertEqual(self.payments.refunded[self.order.charge.charge_id], Decimal("0.00"))
        self.assertEqual(self.stock.on_hand, {"north": {"x": 0}, "south": {"x": 0}})
        self.assertEqual(self.orders.get("purchase").status, "dispatched")
        self.assertFalse(self.orders.cancellations)
        self.shipping.fail_on_cancel_number = None
        self.assertEqual(self.service.cancel_order("purchase", "cancel").refunded_amount,
                         Decimal("36.00"))
        self.assertEqual(self.shipping.cancel_attempts, 3)
        self.assertEqual(len(self.shipping.cancellations), 2)

    def test_store_and_publication_failures_are_retryable(self):
        self.orders.fail_save_cancellation = True
        with self.assertRaises(RuntimeError):
            self.service.cancel_order("purchase", "cancel")
        self.assertEqual(self.payments.refunded[self.order.charge.charge_id], Decimal("36.00"))
        self.assertEqual(self.stock.on_hand, {"north": {"x": 2}, "south": {"x": 1}})
        self.assertFalse(self.orders.cancellations)
        self.orders.fail_save_cancellation = False
        self.events.fail_publish = True
        self.service.cancel_order("purchase", "cancel")
        self.assertEqual(len(self.orders.pending_events()), 1)
        self.events.fail_publish = False
        self.service.cancel_order("purchase", "cancel")
        self.assertFalse(self.orders.pending_events())
        self.assertEqual(self.shipping.cancel_attempts, 2)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(len(self.stock.restorations), 1)

    def test_fully_returned_order_cancels_with_zero_refund(self):
        lines = tuple(ReturnLine(s.shipment_id, "x", a.quantity)
                      for s in self.order.shipments for a in s.allocations)
        self.service.return_items("purchase", "return", lines)
        receipt = self.service.cancel_order("purchase", "cancel")
        self.assertEqual(receipt.refunded_amount, Decimal("0.00"))
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(len(self.stock.restorations), 1)


if __name__ == "__main__":
    unittest.main()
