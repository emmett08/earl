"""Cancellation after partial returns and recoverable carrier failures."""

import json
import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, IdempotencyConflict, InMemoryEventSink,
    InMemoryOrderStore, InMemoryPayments, InMemoryPricing, InMemoryShipping,
    InMemoryStock, RequestedLine, ReturnLine,
)


class CancellationTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock({"north": {"lamp": 2}, "south": {"lamp": 1}},
                                   priorities=("north", "south"))
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(InMemoryPricing({"lamp": Decimal("10.00")}),
                                       self.stock, self.payments, self.shipping, self.orders, self.events)
        self.order = self.service.checkout(CheckoutRequest(
            "order", "customer", (RequestedLine("lamp", 3),), "address", "token"))

    def test_partial_return_then_cancellation(self):
        north, south = self.order.shipments
        self.service.return_items("order", "return", (ReturnLine(north.shipment_id, "lamp", 1),))
        receipt = self.service.cancel_order("order", "cancel")
        self.assertEqual(receipt.refunded_amount, Decimal("24.00"))
        self.assertEqual(self.payments.refunded[self.order.charge.charge_id], Decimal("36.00"))
        self.assertEqual(self.stock.on_hand, {"north": {"lamp": 2}, "south": {"lamp": 1}})
        self.assertEqual(self.shipping.cancelled, {north.shipment_id, south.shipment_id})
        self.assertEqual(self.orders.get("order").status, "cancelled")
        self.assertEqual(self.orders.get("order").shipments, self.order.shipments)
        self.assertIn("return", self.orders.returns)
        event = list(self.events.events.values())[-1]
        self.assertEqual(event.name, "OrderCancelled")
        self.assertEqual(dict(event.data)["cancellation_request_id"], "cancel")
        self.assertEqual(json.loads(dict(event.data)["allocations"]), [
            {"warehouse_id": "north", "sku": "lamp", "quantity": 1},
            {"warehouse_id": "south", "sku": "lamp", "quantity": 1},
        ])
        self.assertIs(self.service.cancel_order("order", "cancel"), receipt)
        self.assertEqual(self.shipping.cancel_attempts, 2)
        self.assertEqual(len(self.payments.refunds), 2)
        self.assertEqual(len(self.stock.restorations), 2)
        with self.assertRaises(IdempotencyConflict):
            self.service.cancel_order("order", "another")
        with self.assertRaises(ValueError):
            self.service.return_items("order", "new-return", (ReturnLine(south.shipment_id, "lamp", 1),))

    def test_second_carrier_failure_resumes_original_request(self):
        self.shipping.fail_on_cancel_number = 2
        with self.assertRaises(RuntimeError):
            self.service.cancel_order("order", "cancel")
        self.assertEqual(len(self.shipping.cancelled), 1)
        self.assertFalse(self.payments.refunds)
        self.assertFalse(self.stock.restorations)
        self.assertNotIn("cancel", self.orders.cancellations)
        self.assertEqual(self.orders.get("order").status, "dispatched")
        self.assertEqual(len(self.events.events), 1)
        with self.assertRaises(IdempotencyConflict):
            self.service.cancel_order("order", "other")
        self.shipping.fail_on_cancel_number = None
        receipt = self.service.cancel_order("order", "cancel")
        self.assertEqual(receipt.refunded_amount, Decimal("36.00"))
        self.assertEqual(self.shipping.cancel_attempts, 3)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(len(self.stock.restorations), 1)

    def test_unknown_order_and_reused_id_have_no_effect(self):
        with self.assertRaises(ValueError):
            self.service.cancel_order("missing", "cancel")
        self.stock.on_hand["north"]["lamp"] = 1
        other = self.service.checkout(CheckoutRequest(
            "other", "customer", (RequestedLine("lamp", 1),), "address", "token"))
        self.service.cancel_order("order", "cancel")
        with self.assertRaises(IdempotencyConflict):
            self.service.cancel_order("other", "cancel")
        self.assertEqual(self.orders.get("other"), other)

    def test_store_and_event_failure_retries_without_external_effects(self):
        self.orders.fail_save = True
        with self.assertRaises(RuntimeError):
            self.service.cancel_order("order", "cancel")
        self.orders.fail_save = False
        self.events.fail_publish = True
        receipt = self.service.cancel_order("order", "cancel")
        self.assertEqual(len(self.orders.pending_events()), 1)
        self.events.fail_publish = False
        self.assertIs(self.service.cancel_order("order", "cancel"), receipt)
        self.assertEqual(self.shipping.cancel_attempts, 2)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(len(self.stock.restorations), 1)
        self.assertFalse(self.orders.pending_events())

    def test_all_units_returned_before_cancellation_has_no_extra_refund_or_stock(self):
        north, south = self.order.shipments
        self.service.return_items("order", "return-all", (
            ReturnLine(north.shipment_id, "lamp", 2),
            ReturnLine(south.shipment_id, "lamp", 1),
        ))
        receipt = self.service.cancel_order("order", "cancel")
        self.assertEqual(receipt.refunded_amount, Decimal("0.00"))
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(self.stock.on_hand, {"north": {"lamp": 2}, "south": {"lamp": 1}})
        self.assertEqual(json.loads(dict(list(self.events.events.values())[-1].data)["allocations"]), [])


if __name__ == "__main__":
    unittest.main()
