"""Partial return effects and retry boundaries."""

import json
import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, IdempotencyConflict, InMemoryEventSink,
    InMemoryOrderStore, InMemoryPayments, InMemoryPricing, InMemoryShipping,
    InMemoryStock, RequestedLine, ReturnLine,
)


class ReturnsTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock({"north": {"lamp": 2}, "south": {"lamp": 1}}, priorities=("north", "south"))
        self.payments = InMemoryPayments()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(InMemoryPricing({"lamp": Decimal("10.00")}), self.stock,
                                       self.payments, InMemoryShipping(), self.orders, self.events)
        self.order = self.service.checkout(CheckoutRequest("order", "customer", (RequestedLine("lamp", 3),),
                                                           "address", "token"))
        self.north, self.south = self.order.shipments
        self.lines = (ReturnLine(self.north.shipment_id, "lamp", 1),
                      ReturnLine(self.south.shipment_id, "lamp", 1))

    def test_split_refund_and_replay(self):
        receipt = self.service.return_items("order", "return-1", self.lines)
        self.assertEqual(receipt.refunded_amount, Decimal("24.00"))
        self.assertEqual(self.stock.on_hand, {"north": {"lamp": 1}, "south": {"lamp": 1}})
        self.assertIs(self.service.return_items("order", "return-1", self.lines), receipt)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(self.order.shipments, (self.north, self.south))
        event = list(self.events.events.values())[-1]
        self.assertEqual(event.name, "ItemsReturned")
        self.assertEqual(dict(event.data)["refunded_amount"], "24.00")
        self.assertEqual([a["warehouse_id"] for a in json.loads(dict(event.data)["allocations"])],
                         ["north", "south"])
        with self.assertRaises(IdempotencyConflict):
            self.service.return_items("order", "return-1", (self.lines[0],))
        with self.assertRaises(ValueError):
            self.service.return_items("order", "return-2", self.lines)
        self.assertEqual(len(self.payments.refunds), 1)

    def test_invalid_returns_have_no_effect(self):
        for order, lines in (("missing", self.lines),
                             ("order", (ReturnLine("unknown", "lamp", 1),)),
                             ("order", (ReturnLine(self.north.shipment_id, "other", 1),)),
                             ("order", (ReturnLine(self.north.shipment_id, "lamp", 3),))):
            with self.assertRaises(ValueError):
                self.service.return_items(order, "bad", lines)
        with self.assertRaises(ValueError):
            ReturnLine(self.north.shipment_id, "lamp", 0)
        self.assertFalse(self.orders.returns)
        self.assertFalse(self.payments.refunds)
        self.assertFalse(self.stock.restorations)
        self.assertEqual(len(self.events.events), 1)

    def test_refund_and_post_refund_failures_retry_once(self):
        self.payments.fail_refund = True
        with self.assertRaises(RuntimeError):
            self.service.return_items("order", "return-1", self.lines)
        self.assertFalse(self.orders.returns)
        self.assertEqual(self.stock.on_hand["north"]["lamp"], 0)
        self.payments.fail_refund = False
        self.stock.fail_release = True
        with self.assertRaises(RuntimeError):
            self.service.return_items("order", "return-1", self.lines)
        self.assertEqual(len(self.payments.refunds), 1)
        self.stock.fail_release = False
        self.orders.fail_save = True
        with self.assertRaises(RuntimeError):
            self.service.return_items("order", "return-1", self.lines)
        self.assertFalse(self.orders.returns)
        self.orders.fail_save = False
        self.service.return_items("order", "return-1", self.lines)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(len(self.stock.restorations), 1)

    def test_publication_failure_keeps_event(self):
        self.events.fail_publish = True
        receipt = self.service.return_items("order", "return-1", self.lines)
        self.assertEqual(len(self.orders.pending_events()), 1)
        self.events.fail_publish = False
        self.assertIs(self.service.return_items("order", "return-1", self.lines), receipt)
        self.assertFalse(self.orders.pending_events())
        self.assertEqual(len(self.payments.refunds), 1)


if __name__ == "__main__":
    unittest.main()
