import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, CompensationFailure, IdempotencyConflict,
    InMemoryEventSink, InMemoryOrderStore, InMemoryPayments, InMemoryPricing,
    InMemoryShipping, InMemoryStock, RefundUnresolved, RequestedLine, ReturnLine,
)


class RefundReconciliationTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock({"lamp": 2})
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(InMemoryPricing({"lamp": Decimal("10.00")}),
                                       self.stock, self.payments, self.shipping,
                                       self.orders, self.events)
        self.request = CheckoutRequest("purchase", "customer", (RequestedLine("lamp", 1),),
                                       "address", "token")

    def test_provider_applies_then_loses_acknowledgement_once(self):
        charge = self.payments.capture(Decimal("12.00"), "GBP", "token", "capture")
        self.payments.fail_after_refund = True
        with self.assertRaises(RuntimeError):
            self.payments.refund(charge, Decimal("12.00"), "refund")
        self.assertEqual(self.payments.refund_status("refund"), "applied")
        self.payments.refund(charge, Decimal("12.00"), "refund")
        self.assertEqual(self.payments.refunded[charge.charge_id], Decimal("12.00"))
        self.assertEqual(self.payments.refund_status("missing"), "not_applied")
        self.payments.unknown_refunds.add("missing")
        self.assertEqual(self.payments.refund_status("missing"), "unknown")

    def test_return_reconciles_and_blocks_conflicting_work_while_unknown(self):
        order = self.service.checkout(self.request)
        line = (ReturnLine(order.shipments[0].shipment_id, "lamp", 1),)
        self.payments.fail_after_refund = True
        with self.assertRaises(RuntimeError):
            self.service.return_items("purchase", "return", line)
        key = next(iter(self.payments.refunds))
        self.payments.unknown_refunds.add(key)
        with self.assertRaises(RefundUnresolved):
            self.service.return_items("purchase", "return", line)
        with self.assertRaises(IdempotencyConflict):
            self.service.return_items("purchase", "other", line)
        with self.assertRaises(ValueError):
            self.service.cancel_order("purchase", "cancel")
        self.assertFalse(self.orders.returns)
        self.assertEqual(len(self.events.events), 1)
        self.payments.unknown_refunds.remove(key)
        receipt = self.service.return_items("purchase", "return", line)
        self.assertEqual(receipt.refunded_amount, Decimal("12.00"))
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(self.stock.on_hand["lamp"], 2)

    def test_cancellation_reconciles_without_double_refund(self):
        order = self.service.checkout(self.request)
        self.payments.fail_after_refund = True
        with self.assertRaises(RuntimeError):
            self.service.cancel_order("purchase", "cancel")
        key = next(iter(self.payments.refunds))
        self.payments.unknown_refunds.add(key)
        with self.assertRaises(RefundUnresolved):
            self.service.cancel_order("purchase", "cancel")
        self.assertEqual(self.orders.get("purchase").status, "dispatched")
        self.assertEqual(len(self.events.events), 1)
        self.payments.unknown_refunds.remove(key)
        receipt = self.service.cancel_order("purchase", "cancel")
        self.assertEqual(receipt.refunded_amount, Decimal("12.00"))
        self.assertEqual(self.stock.on_hand["lamp"], 2)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(len(self.events.events), 2)
        self.assertEqual(self.orders.get("purchase").status, "cancelled")

    def test_checkout_rollback_reconciles_before_fresh_attempt(self):
        self.shipping.fail_dispatch = True
        self.payments.fail_after_refund = True
        with self.assertRaises(CompensationFailure):
            self.service.checkout(self.request)
        old_charge = next(iter(self.payments.charges.values()))
        key = next(iter(self.payments.refunds))
        self.payments.unknown_refunds.add(key)
        self.shipping.fail_dispatch = False
        with self.assertRaises(CompensationFailure):
            self.service.checkout(self.request)
        self.assertEqual(len(self.payments.charges), 1)
        self.assertEqual(self.orders.attempts["purchase"], 1)
        self.assertFalse(self.events.events)
        self.payments.unknown_refunds.remove(key)
        order = self.service.checkout(self.request)
        self.assertNotEqual(order.charge, old_charge)
        self.assertEqual(self.payments.refunded[old_charge.charge_id], old_charge.amount)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(self.stock.on_hand["lamp"], 1)
        self.assertEqual(len(self.events.events), 1)


if __name__ == "__main__":
    unittest.main()
