"""Purchase orchestration, idempotency and durable event delivery."""

from __future__ import annotations

import hashlib
import json
from decimal import Decimal

from .domain import (
    CancellationReceipt, CheckoutRequest, CompensationFailure, DispatchFailure, Event, IdempotencyConflict, Order,
    Reservation, Charge, Shipment, Allocation, ReturnLine, ReturnReceipt, RefundUnresolved, RollbackAttempt,
)
from .ports import EventSink, OrderStore, PaymentPort, PricingPort, ShippingPort, StockPort


def request_fingerprint(request: CheckoutRequest) -> str:
    # The token participates in the identity but is never written into an event.
    serialised = json.dumps(
        [request.customer_id, [(line.sku, line.quantity) for line in request.lines],
         request.address, request.payment_token],
        separators=(",", ":"), ensure_ascii=False,
    )
    return hashlib.sha256(serialised.encode("utf-8")).hexdigest()


class CheckoutService:
    def __init__(
        self, pricing: PricingPort, stock: StockPort, payments: PaymentPort,
        shipping: ShippingPort, orders: OrderStore, events: EventSink,
    ) -> None:
        self.pricing = pricing
        self.stock = stock
        self.payments = payments
        self.shipping = shipping
        self.orders = orders
        self.events = events

    def _refund(self, charge: Charge, amount: Decimal, key: str) -> None:
        status = self.payments.refund_status(key)
        if status == "applied":
            return
        if status == "unknown":
            raise RefundUnresolved(key)
        if status != "not_applied":
            raise ValueError(f"invalid refund status: {status}")
        # An exception after application still reaches the caller. The next
        # invocation checks the same key before touching the provider again.
        self.payments.refund(charge, amount, key)

    def _finish_rollback(self, request_id: str) -> None:
        rollback = self.orders.pending_rollback(request_id)
        if rollback is None:
            return
        original, key = rollback.original, rollback.operation_key
        errors: list[Exception] = []
        for shipment in reversed(rollback.shipments):
            try:
                self.shipping.cancel(shipment, key + ":rollback")
            except Exception as error:
                errors.append(error)
        if rollback.charge is not None:
            try:
                self._refund(rollback.charge, rollback.charge.amount, key + ":rollback")
            except Exception as error:
                errors.append(error)
        if rollback.reservation is not None:
            try:
                self.stock.release(rollback.reservation)
            except Exception as error:
                errors.append(error)
        if errors:
            raise CompensationFailure(original, tuple(errors)) from original
        self.orders.clear_rollback(request_id)

    def checkout(self, request: CheckoutRequest) -> Order:
        fingerprint = request_fingerprint(request)
        previous = self.orders.get(request.request_id)
        if previous is not None:
            if previous.request_fingerprint != fingerprint:
                raise IdempotencyConflict(request.request_id)
            self.retry_events()
            return previous

        pending = self.orders.pending_rollback(request.request_id)
        if pending is not None:
            # begin_attempt checks the fixed fingerprint before any fresh effect.
            self.orders.check_fingerprint(request.request_id, fingerprint)
            self._finish_rollback(request.request_id)

        quote = self.pricing.quote(request.lines)
        order_id = "ord-" + hashlib.sha256(request.request_id.encode()).hexdigest()[:20]
        attempt = self.orders.begin_attempt(request.request_id, fingerprint)
        operation_key = f"{request.request_id}:attempt:{attempt}"
        reservation: Reservation | None = None
        charge: Charge | None = None
        shipments: tuple[Shipment, ...] = ()
        try:
            reservation = self.stock.reserve(request.lines, operation_key)
            charge = self.payments.capture(quote.total, quote.currency, request.payment_token, operation_key)
            shipments = self.shipping.dispatch(order_id, reservation, request.address, operation_key)
            if not shipments:
                raise ValueError("dispatch returned no shipments")
            order = Order(
                order_id=order_id, request_id=request.request_id,
                request_fingerprint=fingerprint, customer_id=request.customer_id,
                address=request.address, quote=quote, reservation=reservation,
                charge=charge, shipments=shipments, status="dispatched",
            )
            event = Event(
                event_id=f"{order_id}:dispatched", name="OrderDispatched", order_id=order_id,
                data=(
                    ("customer_id", request.customer_id), ("shipment_count", str(len(shipments))),
                    ("allocations", json.dumps([
                        {"warehouse_id": a.warehouse_id, "sku": a.sku, "quantity": a.quantity}
                        for a in order.allocations
                    ])),
                    ("shipments", json.dumps([
                        {"shipment_id": shipment.shipment_id, "warehouse_id": shipment.warehouse_id,
                         "allocations": [{"sku": a.sku, "quantity": a.quantity} for a in shipment.allocations]}
                        for shipment in shipments
                    ])),
                ),
            )
            self.orders.save(order, (event,))
        except Exception as original:
            if isinstance(original, DispatchFailure):
                shipments = original.partial_shipments
            self.orders.save_rollback(request.request_id, RollbackAttempt(
                original, operation_key, reservation, charge, shipments,
            ))
            self._finish_rollback(request.request_id)
            raise
        self.retry_events()
        return order

    def retry_events(self) -> int:
        """Send pending events, retaining any that the sink rejects for a later retry."""
        count = 0
        for event in self.orders.pending_events():
            try:
                self.events.publish(event)
            except Exception:
                break
            self.orders.ack(event.event_id)
            count += 1
        return count

    def return_items(
        self, order_request_id: str, return_request_id: str, lines: tuple[ReturnLine, ...],
    ) -> ReturnReceipt:
        order = self.orders.get(order_request_id)
        if order is None:
            raise ValueError("unknown order")
        if not return_request_id or not isinstance(lines, tuple) or not lines:
            raise ValueError("return needs an ID and lines")
        if any(not isinstance(line, ReturnLine) or not line.shipment_id or not line.sku
               or type(line.quantity) is not int or line.quantity <= 0 for line in lines):
            raise ValueError("invalid return line")
        shipments = {shipment.shipment_id: shipment for shipment in order.shipments}
        prices = {line.sku: line.unit_price + line.unit_tax for line in order.quote.lines}
        allocations = []
        amount = Decimal("0.00")
        for line in lines:
            shipment = shipments.get(line.shipment_id)
            if shipment is None:
                raise ValueError("unknown shipment")
            if line.sku not in {allocation.sku for allocation in shipment.allocations}:
                raise ValueError("SKU not present on shipment")
            allocations.append(Allocation(line.sku, line.quantity, shipment.warehouse_id))
            amount += prices[line.sku] * line.quantity
        previous = self.orders.begin_return(order, return_request_id, lines)
        if previous is not None:
            self.retry_events()
            return previous

        # Both ports deduplicate by this request-specific key. A failure between
        # these operations or before the store commit can be retried safely.
        key = "return:" + hashlib.sha256(return_request_id.encode()).hexdigest()
        self._refund(order.charge, amount, key)
        self.stock.restore(tuple(allocations), key)
        receipt = ReturnReceipt(return_request_id, amount, lines)
        event = Event(
            event_id=f"{order.order_id}:{key}", name="ItemsReturned", order_id=order.order_id,
            data=(("return_request_id", return_request_id),
                  ("refunded_amount", str(amount)),
                  ("allocations", json.dumps([
                      {"shipment_id": line.shipment_id, "warehouse_id": allocation.warehouse_id,
                       "sku": line.sku, "quantity": line.quantity}
                      for line, allocation in zip(lines, allocations)
                  ]))),
        )
        self.orders.complete_return(receipt, event)
        self.retry_events()
        return receipt

    def cancel_order(self, order_request_id: str, cancellation_request_id: str) -> CancellationReceipt:
        order = self.orders.get(order_request_id)
        if order is None:
            raise ValueError("unknown order")
        if not cancellation_request_id:
            raise ValueError("cancellation needs an ID")

        returned: dict[tuple[str, str], int] = {}
        for line in self.orders.returned_lines(order):
            pair = (line.shipment_id, line.sku)
            returned[pair] = returned.get(pair, 0) + line.quantity
        prices = {line.sku: line.unit_price + line.unit_tax for line in order.quote.lines}
        allocations: list[Allocation] = []
        amount = Decimal("0.00")
        for shipment in order.shipments:
            for allocation in shipment.allocations:
                remaining = allocation.quantity - returned.get((shipment.shipment_id, allocation.sku), 0)
                if remaining:
                    allocations.append(Allocation(allocation.sku, remaining, shipment.warehouse_id))
                    amount += prices[allocation.sku] * remaining
        affected = tuple(allocations)
        previous = self.orders.begin_cancellation(order, cancellation_request_id, affected, amount)
        if previous is not None:
            self.retry_events()
            return previous

        key = "cancel:" + hashlib.sha256(cancellation_request_id.encode()).hexdigest()
        for shipment in order.shipments:
            self.shipping.cancel(shipment, f"{key}:{shipment.shipment_id}")
        if amount:
            self._refund(order.charge, amount, key)
        self.stock.restore(affected, key)
        receipt = CancellationReceipt(cancellation_request_id, amount)
        event = Event(
            event_id=f"{order.order_id}:{key}", name="OrderCancelled", order_id=order.order_id,
            data=(("cancellation_request_id", cancellation_request_id),
                  ("refunded_amount", str(amount)),
                  ("allocations", json.dumps([
                      {"warehouse_id": a.warehouse_id, "sku": a.sku, "quantity": a.quantity}
                      for a in affected
                  ]))),
        )
        self.orders.complete_cancellation(order, receipt, event)
        self.retry_events()
        return receipt
