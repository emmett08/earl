"""A bounded retry follows the order store's outbox across fulfilment paths."""

import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, InMemoryEventSink, InMemoryOrderStore,
    InMemoryPayments, InMemoryPricing, InMemoryShipping, InMemoryStock,
    RequestedLine,
)


class RecordingSink(InMemoryEventSink):
    def __init__(self):
        super().__init__()
        self.attempted = []
        self.reject_once = None

    def publish(self, event):
        self.attempted.append(event.event_id)
        if self.reject_once == event.event_id:
            self.reject_once = None
            raise RuntimeError("temporary rejection")
        super().publish(event)


class BoundedEventDeliveryTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock(
            {name: {"lamp": 10} for name in ("north", "south", "east")},
            priorities=("north", "south", "east"),
        )
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = RecordingSink()
        self.service = CheckoutService(
            InMemoryPricing({"lamp": Decimal("10.00")}), self.stock,
            self.payments, self.shipping, self.orders, self.events,
        )

    def make_pending_orders(self):
        self.events.fail_publish = True
        created = []
        for index in range(5):
            if index == 1:
                self.stock.set_warehouse_open("north", False)
            if index == 2:
                self.stock.set_warehouse_open("north", True)
                self.shipping.reject_warehouses.add("north")
            if index == 3:
                self.shipping.reject_warehouses.clear()
            request = CheckoutRequest(
                f"request-{index}", "customer", (RequestedLine("lamp", 1),),
                "address", "token",
            )
            created.append(self.service.checkout(request))
        self.events.fail_publish = False
        self.events.attempted.clear()
        return created

    def test_successive_batches_follow_recording_order_without_other_effects(self):
        orders = self.make_pending_orders()
        self.assertEqual(orders[1].allocations[0].warehouse_id, "south")
        self.assertEqual(orders[2].allocations[0].warehouse_id, "south")
        expected = [f"{order.order_id}:dispatched" for order in orders]
        effects = (len(self.payments.charges), len(self.stock.reservations),
                   self.shipping.shipment_attempts)

        self.assertEqual([self.service.retry_events(max_events=2) for _ in range(4)],
                         [2, 2, 1, 0])
        self.assertEqual(self.events.attempted, expected)
        self.assertEqual(list(self.events.events), expected)
        self.assertFalse(self.orders.pending_events())
        self.assertEqual((len(self.payments.charges), len(self.stock.reservations),
                          self.shipping.shipment_attempts), effects)

    def test_failure_keeps_failed_and_later_events_for_next_batch(self):
        orders = self.make_pending_orders()
        expected = [f"{order.order_id}:dispatched" for order in orders]
        self.events.reject_once = expected[1]

        self.assertEqual(self.service.retry_events(3), 1)
        self.assertEqual(self.events.attempted, expected[:2])
        self.assertEqual([event.event_id for event in self.orders.pending_events()], expected[1:])
        self.assertEqual(self.service.retry_events(2), 2)
        self.assertEqual(self.service.retry_events(), 2)
        self.assertEqual(list(self.events.events), expected)
        self.assertEqual(self.events.attempted, expected[:2] + expected[1:])

    def test_invalid_limits_publish_nothing(self):
        self.make_pending_orders()
        pending = self.orders.pending_events()
        for invalid in (0, -1, True, 1.0, "2"):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                self.service.retry_events(invalid)
        self.assertEqual(self.events.attempted, [])
        self.assertEqual(self.orders.pending_events(), pending)


if __name__ == "__main__":
    unittest.main()
