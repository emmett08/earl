"""Carrier rejection substitutes unused stock without changing the purchase."""

import json
import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, InMemoryEventSink, InMemoryOrderStore,
    InMemoryPayments, InMemoryPricing, InMemoryShipping, InMemoryStock,
    OutOfStock, RequestedLine,
)


class CarrierSubstitutionTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock(
            {"north": {"lamp": 2}, "south": {"lamp": 2}, "east": {"lamp": 3}},
            priorities=("north", "south", "east"),
        )
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(
            InMemoryPricing({"lamp": Decimal("10.00")}), self.stock,
            self.payments, self.shipping, self.orders, self.events,
        )

    def request(self, key="rejected"):
        return CheckoutRequest(key, "customer", (RequestedLine("lamp", 3),), "address", "token")

    def test_rejected_source_is_replaced_in_order_event_and_stock(self):
        self.shipping.reject_warehouses.add("north")
        order = self.service.checkout(self.request())
        self.assertEqual([(a.warehouse_id, a.quantity) for a in order.allocations],
                         [("south", 2), ("east", 1)])
        self.assertEqual([s.warehouse_id for s in order.shipments], ["south", "east"])
        self.assertEqual([self.stock.on_hand[w]["lamp"] for w in self.stock.priorities], [2, 0, 2])
        self.assertEqual(order.quote.lines[0].quantity, 3)
        self.assertEqual(order.charge.amount, order.quote.total)
        self.assertEqual(len(self.payments.charges), 1)
        event = next(iter(self.events.events.values()))
        data = dict(event.data)
        self.assertEqual([a["warehouse_id"] for a in json.loads(data["allocations"])], ["south", "east"])
        self.assertEqual([s["warehouse_id"] for s in json.loads(data["shipments"])], ["south", "east"])
        self.assertIs(self.service.checkout(self.request()), order)
        self.assertEqual(self.shipping.shipment_attempts, 3)

    def test_no_open_replacement_compensates_then_retry_succeeds(self):
        self.shipping.reject_warehouses.add("south")
        self.stock.set_warehouse_open("east", False)
        with self.assertRaises(OutOfStock):
            self.service.checkout(self.request())
        self.assertEqual([self.stock.on_hand[w]["lamp"] for w in self.stock.priorities], [2, 2, 3])
        self.assertEqual(self.shipping.cancelled, set(self.shipping.shipments))
        self.assertFalse(self.stock.reservations)
        self.assertFalse(self.orders.orders)
        self.assertFalse(self.events.events)
        charge = next(iter(self.payments.charges.values()))
        self.assertEqual(self.payments.refunded[charge.charge_id], charge.amount)
        self.assertEqual(len(self.payments.refunds), 1)
        self.shipping.reject_warehouses.clear()
        order = self.service.checkout(self.request())
        self.assertIn(":attempt:2", order.charge.charge_id)
        self.assertEqual(len(self.payments.charges), 2)

    def test_event_retry_does_not_redispatch(self):
        self.shipping.reject_warehouses.add("north")
        self.events.fail_publish = True
        order = self.service.checkout(self.request())
        attempts = self.shipping.shipment_attempts
        self.events.fail_publish = False
        self.assertIs(self.service.checkout(self.request()), order)
        self.assertEqual(self.shipping.shipment_attempts, attempts)
        self.assertEqual(len(self.events.events), 1)


if __name__ == "__main__":
    unittest.main()
