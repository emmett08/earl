"""Warehouse availability applies to new reservations, not completed orders."""

import json
import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, InMemoryEventSink, InMemoryOrderStore,
    InMemoryPayments, InMemoryPricing, InMemoryShipping, InMemoryStock,
    OutOfStock, RequestedLine,
)


class WarehouseAvailabilityTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock(
            {"north": {"lamp": 2, "cord": 1},
             "south": {"lamp": 2, "cord": 1},
             "east": {"lamp": 3, "cord": 1}},
            priorities=("north", "south", "east"),
        )
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(
            InMemoryPricing({"lamp": Decimal("10.00"), "cord": Decimal("2.00")}),
            self.stock, self.payments, self.shipping, self.orders, self.events,
        )

    def request(self, key, lines=(RequestedLine("lamp", 3),)):
        return CheckoutRequest(key, "customer", lines, "10 Test Street", "token")

    def test_closed_warehouse_is_skipped_and_reopening_serves_later_order(self):
        self.stock.set_warehouse_open("north", False)
        order = self.service.checkout(self.request("closed"))
        self.assertEqual([(a.warehouse_id, a.quantity) for a in order.allocations],
                         [("south", 2), ("east", 1)])
        self.assertEqual([s.warehouse_id for s in order.shipments], ["south", "east"])
        self.assertEqual(len(self.payments.charges), 1)
        event = next(iter(self.events.events.values()))
        self.assertEqual(json.loads(dict(event.data)["allocations"]), [
            {"warehouse_id": a.warehouse_id, "sku": a.sku, "quantity": a.quantity}
            for a in order.allocations
        ])
        self.assertEqual(self.stock.on_hand["north"]["lamp"], 2)

        original_shipments = order.shipments
        self.stock.set_warehouse_open("north", True)
        self.assertIs(self.service.checkout(self.request("closed")), order)
        self.assertEqual(order.shipments, original_shipments)
        self.assertEqual(len(self.payments.charges), 1)
        later = self.service.checkout(self.request("reopened", (RequestedLine("lamp", 2),)))
        self.assertEqual([(a.warehouse_id, a.quantity) for a in later.allocations], [("north", 2)])

    def test_shortage_in_open_warehouses_is_atomic_and_retry_can_succeed(self):
        self.stock.set_warehouse_open("north", False)
        before = {name: dict(stock) for name, stock in self.stock.on_hand.items()}
        request = self.request("retry", (RequestedLine("cord", 1), RequestedLine("lamp", 6)))
        with self.assertRaises(OutOfStock):
            self.service.checkout(request)
        self.assertEqual(self.stock.on_hand, before)
        self.assertFalse(self.stock.reservations)
        self.assertFalse(self.payments.charges)
        self.assertFalse(self.shipping.shipments)
        self.assertFalse(self.orders.orders)
        self.assertFalse(self.orders.pending_events())
        self.assertFalse(self.events.events)

        self.stock.set_warehouse_open("north", True)
        order = self.service.checkout(request)
        self.assertEqual(sum(a.quantity for a in order.allocations if a.sku == "lamp"), 6)
        self.assertIn(":attempt:2", order.charge.charge_id)

    def test_flat_stock_and_unknown_warehouse(self):
        flat = InMemoryStock({"lamp": 1})
        with self.assertRaises(ValueError):
            flat.set_warehouse_open("missing", False)
        flat.set_warehouse_open("main", False)
        with self.assertRaises(OutOfStock):
            flat.reserve((RequestedLine("lamp", 1),), "closed")
        self.assertEqual(flat.on_hand, {"lamp": 1})
        flat.set_warehouse_open("main", True)
        self.assertEqual(flat.reserve((RequestedLine("lamp", 1),), "open").allocations[0].warehouse_id, "main")


if __name__ == "__main__":
    unittest.main()
