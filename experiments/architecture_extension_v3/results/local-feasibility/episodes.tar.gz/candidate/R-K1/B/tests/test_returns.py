"""Partial return effects and recovery after each external boundary."""

import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, IdempotencyConflict, InMemoryEventSink,
    InMemoryOrderStore, InMemoryPayments, InMemoryPricing, InMemoryShipping,
    InMemoryStock, RequestedLine, ReturnLine,
)


class ReturnTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock({"north": {"lamp": 2}, "south": {"lamp": 2}},
                                   priorities=("north", "south"))
        self.payments = InMemoryPayments()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(InMemoryPricing({"lamp": Decimal("10.00")}),
                                       self.stock, self.payments, InMemoryShipping(),
                                       self.orders, self.events)
        self.order = self.service.checkout(CheckoutRequest(
            "purchase", "customer", (RequestedLine("lamp", 3),), "address", "token"))
        self.north, self.south = self.order.shipments
        self.lines = (ReturnLine(self.north.shipment_id, "lamp", 1),
                      ReturnLine(self.south.shipment_id, "lamp", 1))

    def test_split_return_replay_event_and_cumulative_limit(self):
        receipt = self.service.return_items("purchase", "return-1", self.lines)
        self.assertEqual(receipt.refunded_amount, Decimal("24.00"))
        self.assertEqual(self.stock.on_hand["north"]["lamp"], 1)
        self.assertEqual(self.stock.on_hand["south"]["lamp"], 2)
        self.assertIs(receipt, self.service.return_items("purchase", "return-1", self.lines))
        self.assertEqual(self.payments.refunded[self.order.charge.charge_id], Decimal("24.00"))
        self.assertEqual(self.order.shipments, (self.north, self.south))
        event = list(self.events.events.values())[-1]
        self.assertEqual(event.name, "ItemsReturned")
        self.assertIn("return-1", dict(event.data)["return_request_id"])
        with self.assertRaises(IdempotencyConflict):
            self.service.return_items("purchase", "return-1", (self.lines[0],))
        with self.assertRaises(ValueError):
            self.service.return_items("purchase", "return-2", (ReturnLine(self.south.shipment_id, "lamp", 1),))
        with self.assertRaises(ValueError):
            self.service.return_items("purchase", "return-2", (ReturnLine(self.north.shipment_id, "lamp", 2),))
        self.assertEqual(len(self.orders.returns), 1)

    def test_invalid_lines_have_no_effect(self):
        before = dict(self.payments.refunded)
        for order_id, lines in [
            ("missing", self.lines),
            ("purchase", (ReturnLine("unknown", "lamp", 1),)),
            ("purchase", (ReturnLine(self.north.shipment_id, "cord", 1),)),
            ("purchase", (ReturnLine(self.north.shipment_id, "lamp", 3),)),
        ]:
            with self.assertRaises(ValueError):
                self.service.return_items(order_id, "invalid", lines)
        with self.assertRaises(ValueError):
            ReturnLine(self.north.shipment_id, "lamp", 0)
        self.assertEqual(self.payments.refunded, before)
        self.assertFalse(self.orders.return_requests)
        self.assertFalse(self.stock.restorations)

    def test_refund_failure_then_retry(self):
        self.payments.fail_refund = True
        with self.assertRaisesRegex(RuntimeError, "refund failed"):
            self.service.return_items("purchase", "return-1", self.lines)
        self.assertFalse(self.orders.returns)
        self.assertFalse(self.stock.restorations)
        self.assertEqual(self.payments.refunded[self.order.charge.charge_id], Decimal("0.00"))
        self.payments.fail_refund = False
        self.service.return_items("purchase", "return-1", self.lines)
        self.assertEqual(self.payments.refunded[self.order.charge.charge_id], Decimal("24.00"))

    def test_restore_and_save_failures_do_not_repeat_refund_or_restore(self):
        self.stock.fail_restore = True
        with self.assertRaisesRegex(RuntimeError, "restore failed"):
            self.service.return_items("purchase", "return-1", self.lines)
        with self.assertRaises(ValueError):
            self.service.return_items("purchase", "other", (ReturnLine(self.south.shipment_id, "lamp", 1),))
        self.stock.fail_restore = False
        self.orders.fail_save_return = True
        with self.assertRaisesRegex(RuntimeError, "transaction failed"):
            self.service.return_items("purchase", "return-1", self.lines)
        self.assertFalse(self.orders.returns)
        self.assertEqual(self.stock.on_hand["north"]["lamp"], 1)
        self.orders.fail_save_return = False
        self.service.return_items("purchase", "return-1", self.lines)
        self.assertEqual(self.stock.on_hand["north"]["lamp"], 1)
        self.assertEqual(len(self.payments.refunds), 1)

    def test_event_failure_retains_outbox(self):
        self.events.fail_publish = True
        receipt = self.service.return_items("purchase", "return-1", self.lines)
        self.assertEqual(len(self.orders.pending_events()), 1)
        self.events.fail_publish = False
        self.assertIs(self.service.return_items("purchase", "return-1", self.lines), receipt)
        self.assertFalse(self.orders.pending_events())
        self.assertEqual(len(self.payments.refunds), 1)


if __name__ == "__main__":
    unittest.main()
