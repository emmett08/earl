"""Purchase orchestration, idempotency and durable event delivery."""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from decimal import Decimal

from .domain import (
    CheckoutRequest, CompensationFailure, DispatchFailure, Event, IdempotencyConflict, Order,
    Reservation, Charge, Shipment, Allocation, ReturnLine, ReturnReceipt, CancellationReceipt,
)
from .ports import EventSink, OrderStore, PaymentPort, PricingPort, ShippingPort, StockPort


def request_fingerprint(request: CheckoutRequest) -> str:
    # The token participates in the identity but is never written into an event.
    serialised = json.dumps(
        [request.customer_id, [(line.sku, line.quantity) for line in request.lines],
         request.address, request.payment_token],
        separators=(",", ":"), ensure_ascii=False,
    )
    return hashlib.sha256(serialised.encode("utf-8")).hexdigest()


class CheckoutService:
    def __init__(
        self, pricing: PricingPort, stock: StockPort, payments: PaymentPort,
        shipping: ShippingPort, orders: OrderStore, events: EventSink,
    ) -> None:
        self.pricing = pricing
        self.stock = stock
        self.payments = payments
        self.shipping = shipping
        self.orders = orders
        self.events = events

    def checkout(self, request: CheckoutRequest) -> Order:
        fingerprint = request_fingerprint(request)
        previous = self.orders.get(request.request_id)
        if previous is not None:
            if previous.request_fingerprint != fingerprint:
                raise IdempotencyConflict(request.request_id)
            self.retry_events()
            return previous

        quote = self.pricing.quote(request.lines)
        order_id = "ord-" + hashlib.sha256(request.request_id.encode()).hexdigest()[:20]
        attempt = self.orders.begin_attempt(request.request_id, fingerprint)
        operation_key = f"{request.request_id}:attempt:{attempt}"
        reservation: Reservation | None = None
        charge: Charge | None = None
        shipments: tuple[Shipment, ...] = ()
        try:
            reservation = self.stock.reserve(request.lines, operation_key)
            charge = self.payments.capture(quote.total, quote.currency, request.payment_token, operation_key)
            shipments = self.shipping.dispatch(order_id, reservation, request.address, operation_key)
            if not shipments:
                raise ValueError("dispatch returned no shipments")
            order = Order(
                order_id=order_id, request_id=request.request_id,
                request_fingerprint=fingerprint, customer_id=request.customer_id,
                address=request.address, quote=quote, reservation=reservation,
                charge=charge, shipments=shipments, status="dispatched",
            )
            event = Event(
                event_id=f"{order_id}:dispatched", name="OrderDispatched", order_id=order_id,
                data=(
                    ("customer_id", request.customer_id), ("shipment_count", str(len(shipments))),
                    ("allocations", json.dumps([
                        {"warehouse_id": a.warehouse_id, "sku": a.sku, "quantity": a.quantity}
                        for a in order.allocations
                    ])),
                    ("shipments", json.dumps([
                        {"shipment_id": shipment.shipment_id, "warehouse_id": shipment.warehouse_id,
                         "allocations": [{"sku": a.sku, "quantity": a.quantity} for a in shipment.allocations]}
                        for shipment in shipments
                    ])),
                ),
            )
            self.orders.save(order, (event,))
        except Exception as original:
            if isinstance(original, DispatchFailure):
                shipments = original.partial_shipments
            # Undo external operations in reverse order. A failed compensation is
            # explicit: the caller must reconcile it before retrying the key.
            compensation_errors: list[Exception] = []
            for shipment in reversed(shipments):
                try:
                    self.shipping.cancel(shipment, operation_key + ":rollback")
                except Exception as error:
                    compensation_errors.append(error)
            if charge is not None:
                try:
                    self.payments.refund(charge, charge.amount, operation_key + ":rollback")
                except Exception as error:
                    compensation_errors.append(error)
            if reservation is not None:
                try:
                    self.stock.release(reservation)
                except Exception as error:
                    compensation_errors.append(error)
            if compensation_errors:
                raise CompensationFailure(original, tuple(compensation_errors)) from original
            raise
        self.retry_events()
        return order

    def return_items(
        self, order_request_id: str, return_request_id: str, lines: tuple[ReturnLine, ...],
    ) -> ReturnReceipt:
        if not return_request_id or not isinstance(lines, tuple) or not lines:
            raise ValueError("return request ID and lines are required")
        if any(not isinstance(line, ReturnLine) for line in lines):
            raise ValueError("invalid return line")
        identity = (order_request_id, lines)
        previous_request = self.orders.get_return_request(return_request_id)
        if previous_request is not None and previous_request != identity:
            raise IdempotencyConflict(return_request_id)
        previous = self.orders.get_return(return_request_id)
        if previous is not None:
            self.retry_events()
            return previous[2]

        order = self.orders.get(order_request_id)
        if order is None:
            raise ValueError("unknown order")
        if order.status != "dispatched":
            raise ValueError("order is not dispatched")
        shipments = {shipment.shipment_id: shipment for shipment in order.shipments}
        quoted = {line.sku: line for line in order.quote.lines}
        shipped = Counter()
        for shipment in order.shipments:
            for allocation in shipment.allocations:
                shipped[(shipment.shipment_id, allocation.sku)] += allocation.quantity
        claimed = Counter()
        for key, prior_lines in self.orders.active_returns(order_request_id):
            if key != return_request_id:
                for line in prior_lines:
                    claimed[(line.shipment_id, line.sku)] += line.quantity
        for line in lines:
            shipment = shipments.get(line.shipment_id)
            if shipment is None:
                raise ValueError("unknown shipment")
            if line.sku not in quoted or not any(a.sku == line.sku for a in shipment.allocations):
                raise ValueError("shipment SKU mismatch")
            claimed[(line.shipment_id, line.sku)] += line.quantity
            if claimed[(line.shipment_id, line.sku)] > shipped[(line.shipment_id, line.sku)]:
                raise ValueError("return exceeds shipped units")

        amount = sum(
            ((quoted[line.sku].unit_price + quoted[line.sku].unit_tax) * line.quantity for line in lines),
            Decimal("0.00"),
        )
        receipt = ReturnReceipt(return_request_id, amount, lines)
        allocations = tuple(
            Allocation(line.sku, line.quantity, shipments[line.shipment_id].warehouse_id) for line in lines
        )
        self.orders.begin_return(order_request_id, return_request_id, lines)
        # A payment key is stable across retries. Once it succeeds, the store holds
        # the claimed units so another return cannot use them while stock recovers.
        already_refunded = any(key == return_request_id for key, _ in self.orders.active_returns(order_request_id))
        if amount and not already_refunded:
            self.payments.refund(order.charge, amount, f"return:{return_request_id}")
        self.orders.mark_refunded(return_request_id)
        self.stock.restore(allocations, f"return:{return_request_id}")
        event = Event(
            event_id=f"{order.order_id}:return:{hashlib.sha256(return_request_id.encode()).hexdigest()}",
            name="ItemsReturned", order_id=order.order_id,
            data=(
                ("return_request_id", return_request_id),
                ("refunded_amount", str(amount)),
                ("shipments", json.dumps([
                    {"shipment_id": line.shipment_id, "warehouse_id": shipments[line.shipment_id].warehouse_id,
                     "sku": line.sku, "quantity": line.quantity} for line in lines
                ])),
            ),
        )
        self.orders.save_return(order_request_id, receipt, event)
        self.retry_events()
        return receipt

    def cancel_order(self, order_request_id: str, cancellation_request_id: str) -> CancellationReceipt:
        if not cancellation_request_id:
            raise ValueError("cancellation request ID is required")
        previous = self.orders.get_cancellation(cancellation_request_id)
        if previous is not None and previous[0] != order_request_id:
            raise IdempotencyConflict(cancellation_request_id)
        if previous is not None and previous[3]:
            self.retry_events()
            return previous[2]

        order = self.orders.get(order_request_id)
        if order is None:
            raise ValueError("unknown order")
        if previous is None:
            if order.status != "dispatched":
                raise IdempotencyConflict(order_request_id)
            returned = Counter()
            for _, lines in self.orders.active_returns(order_request_id):
                for line in lines:
                    returned[(line.shipment_id, line.sku)] += line.quantity
            allocations = tuple(
                Allocation(allocation.sku, allocation.quantity - returned[(shipment.shipment_id, allocation.sku)],
                           shipment.warehouse_id)
                for shipment in order.shipments for allocation in shipment.allocations
                if allocation.quantity > returned[(shipment.shipment_id, allocation.sku)]
            )
            quoted = {line.sku: line for line in order.quote.lines}
            amount = sum(
                ((quoted[a.sku].unit_price + quoted[a.sku].unit_tax) * a.quantity for a in allocations),
                Decimal("0.00"),
            )
            receipt = CancellationReceipt(cancellation_request_id, amount)
            self.orders.begin_cancellation(order_request_id, receipt, allocations)
        else:
            _, allocations, receipt, _ = previous

        for shipment in order.shipments:
            if shipment.shipment_id not in self.orders.cancelled_shipments(cancellation_request_id):
                self.shipping.cancel(shipment, f"cancel:{cancellation_request_id}:{shipment.shipment_id}")
                self.orders.mark_shipment_cancelled(cancellation_request_id, shipment.shipment_id)
        if receipt.refunded_amount:
            self.payments.refund(order.charge, receipt.refunded_amount, f"cancel:{cancellation_request_id}")
        if allocations:
            self.stock.restore(allocations, f"cancel:{cancellation_request_id}")
        event = Event(
            event_id=f"{order.order_id}:cancel:{hashlib.sha256(cancellation_request_id.encode()).hexdigest()}",
            name="OrderCancelled", order_id=order.order_id,
            data=(
                ("cancellation_request_id", cancellation_request_id),
                ("refunded_amount", str(receipt.refunded_amount)),
                ("allocations", json.dumps([
                    {"warehouse_id": a.warehouse_id, "sku": a.sku, "quantity": a.quantity}
                    for a in allocations
                ])),
            ),
        )
        self.orders.save_cancellation(order_request_id, receipt, event)
        self.retry_events()
        return receipt

    def retry_events(self) -> int:
        """Send pending events, retaining any that the sink rejects for a later retry."""
        count = 0
        for event in self.orders.pending_events():
            try:
                self.events.publish(event)
            except Exception:
                break
            self.orders.ack(event.event_id)
            count += 1
        return count
