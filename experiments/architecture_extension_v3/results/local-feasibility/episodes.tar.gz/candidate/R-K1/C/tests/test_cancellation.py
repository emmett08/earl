"""Cancellation after a partial return and recovery across external effects."""

import json
import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, IdempotencyConflict, InMemoryEventSink,
    InMemoryOrderStore, InMemoryPayments, InMemoryPricing, InMemoryShipping,
    InMemoryStock, RequestedLine, ReturnLine,
)


class CancellationTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock({"north": {"lamp": 2}, "south": {"lamp": 1}},
                                   priorities=("north", "south"))
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(InMemoryPricing({"lamp": Decimal("10.00")}),
                                       self.stock, self.payments, self.shipping,
                                       self.orders, self.events)
        self.order = self.service.checkout(CheckoutRequest(
            "purchase", "customer", (RequestedLine("lamp", 3),), "address", "token"))
        self.north, self.south = self.order.shipments

    def test_partial_return_cancel_replay_and_history(self):
        self.service.return_items("purchase", "return", (ReturnLine(self.north.shipment_id, "lamp", 1),))
        receipt = self.service.cancel_order("purchase", "cancel")
        self.assertEqual(receipt.refunded_amount, Decimal("24.00"))
        self.assertEqual(self.payments.refunded[self.order.charge.charge_id], Decimal("36.00"))
        self.assertEqual(self.stock.on_hand["north"]["lamp"], 2)
        self.assertEqual(self.stock.on_hand["south"]["lamp"], 1)
        self.assertEqual(self.shipping.cancelled, {self.north.shipment_id, self.south.shipment_id})
        self.assertEqual(self.orders.get("purchase").status, "cancelled")
        self.assertEqual(self.orders.get("purchase").shipments, self.order.shipments)
        self.assertEqual(len(self.orders.returns), 1)
        event = list(self.events.events.values())[-1]
        self.assertEqual(event.name, "OrderCancelled")
        self.assertEqual(dict(event.data)["cancellation_request_id"], "cancel")
        self.assertEqual(json.loads(dict(event.data)["allocations"]), [
            {"warehouse_id": "north", "sku": "lamp", "quantity": 1},
            {"warehouse_id": "south", "sku": "lamp", "quantity": 1},
        ])
        self.assertIs(self.service.cancel_order("purchase", "cancel"), receipt)
        self.assertEqual(self.shipping.cancel_attempts, 2)
        with self.assertRaises(IdempotencyConflict):
            self.service.cancel_order("purchase", "different")
        with self.assertRaises(ValueError):
            self.service.return_items("purchase", "new-return", (ReturnLine(self.north.shipment_id, "lamp", 1),))

    def test_second_carrier_failure_resumes_original_request(self):
        self.shipping.fail_on_cancel_number = 2
        with self.assertRaisesRegex(RuntimeError, "carrier cancellation failed"):
            self.service.cancel_order("purchase", "cancel")
        self.assertEqual(self.shipping.cancelled, {self.north.shipment_id})
        self.assertEqual(self.payments.refunded[self.order.charge.charge_id], Decimal("0.00"))
        self.assertEqual(self.orders.get("purchase").status, "dispatched")
        self.assertEqual(self.stock.on_hand["north"]["lamp"], 0)
        self.assertFalse(any(e.name == "OrderCancelled" for e in self.events.events.values()))
        with self.assertRaises(IdempotencyConflict):
            self.service.cancel_order("purchase", "other")
        self.service.cancel_order("purchase", "cancel")
        self.assertEqual(self.shipping.cancel_attempts, 3)
        self.assertEqual(self.payments.refunded[self.order.charge.charge_id], Decimal("36.00"))
        self.assertEqual(self.stock.on_hand["north"]["lamp"], 2)

    def test_unknown_order_and_id_reuse(self):
        with self.assertRaises(ValueError):
            self.service.cancel_order("missing", "cancel")
        self.assertFalse(self.orders.cancellation_requests)
        self.service.cancel_order("purchase", "cancel")
        with self.assertRaises(IdempotencyConflict):
            self.service.cancel_order("another", "cancel")

    def test_restore_and_event_retry(self):
        self.stock.fail_restore = True
        with self.assertRaisesRegex(RuntimeError, "restore failed"):
            self.service.cancel_order("purchase", "cancel")
        self.assertEqual(self.payments.refunded[self.order.charge.charge_id], Decimal("36.00"))
        self.assertEqual(self.shipping.cancel_attempts, 2)
        self.stock.fail_restore = False
        self.events.fail_publish = True
        receipt = self.service.cancel_order("purchase", "cancel")
        self.assertEqual(len(self.orders.pending_events()), 1)
        self.events.fail_publish = False
        self.assertIs(receipt, self.service.cancel_order("purchase", "cancel"))
        self.assertFalse(self.orders.pending_events())
        self.assertEqual(self.shipping.cancel_attempts, 2)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertEqual(len(self.stock.restorations), 1)


if __name__ == "__main__":
    unittest.main()
