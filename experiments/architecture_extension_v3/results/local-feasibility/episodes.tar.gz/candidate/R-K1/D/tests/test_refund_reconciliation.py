"""Refund acknowledgement loss and uncertain provider status across workflows."""

import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, CompensationFailure, IdempotencyConflict,
    InMemoryEventSink, InMemoryOrderStore, InMemoryPayments, InMemoryPricing,
    InMemoryShipping, InMemoryStock, RefundUnresolved, RequestedLine, ReturnLine,
)


class RefundReconciliationTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock({"lamp": 3})
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(InMemoryPricing({"lamp": Decimal("10.00")}),
                                       self.stock, self.payments, self.shipping,
                                       self.orders, self.events)
        self.request = CheckoutRequest("buy", "customer", (RequestedLine("lamp", 2),), "address", "token")

    def test_payment_key_records_once_and_can_report_uncertainty(self):
        charge = self.payments.capture(Decimal("10.00"), "GBP", "token", "capture")
        self.assertEqual(self.payments.refund_status("refund"), "not_applied")
        self.payments.fail_after_refund = True
        with self.assertRaises(RuntimeError):
            self.payments.refund(charge, Decimal("5.00"), "refund")
        self.assertEqual(self.payments.refund_status("refund"), "applied")
        self.payments.refund(charge, Decimal("5.00"), "refund")
        self.assertEqual(self.payments.refunded[charge.charge_id], Decimal("5.00"))
        self.payments.unknown_refunds.add("refund")
        self.assertEqual(self.payments.refund_status("refund"), "unknown")

    def test_return_reconciles_then_restores_and_emits_once(self):
        order = self.service.checkout(self.request)
        lines = (ReturnLine(order.shipments[0].shipment_id, "lamp", 1),)
        self.payments.fail_after_refund = True
        with self.assertRaises(RuntimeError):
            self.service.return_items("buy", "return", lines)
        self.assertEqual(self.stock.on_hand["lamp"], 1)
        self.payments.unknown_refunds.add("return:return")
        with self.assertRaises(RefundUnresolved):
            self.service.return_items("buy", "return", lines)
        with self.assertRaises(ValueError):
            self.service.return_items("buy", "other", lines)
        self.assertFalse(self.orders.returns)
        self.assertFalse(any(e.name == "ItemsReturned" for e in self.events.events.values()))
        self.payments.unknown_refunds.clear()
        receipt = self.service.return_items("buy", "return", lines)
        self.assertIs(self.service.return_items("buy", "return", lines), receipt)
        self.assertEqual(self.payments.refunded[order.charge.charge_id], Decimal("12.00"))
        self.assertEqual(self.stock.on_hand["lamp"], 2)
        self.assertEqual(len(self.orders.returns), 1)
        self.assertEqual(sum(e.name == "ItemsReturned" for e in self.events.events.values()), 1)

    def test_cancel_reconciles_refund_before_restoration_and_event(self):
        order = self.service.checkout(self.request)
        self.payments.fail_after_refund = True
        with self.assertRaises(RuntimeError):
            self.service.cancel_order("buy", "cancel")
        self.payments.unknown_refunds.add("cancel:cancel")
        with self.assertRaises(RefundUnresolved):
            self.service.cancel_order("buy", "cancel")
        with self.assertRaises(IdempotencyConflict):
            self.service.cancel_order("buy", "other")
        self.assertEqual(self.orders.get("buy").status, "dispatched")
        self.assertEqual(self.stock.on_hand["lamp"], 1)
        self.payments.unknown_refunds.clear()
        self.service.cancel_order("buy", "cancel")
        self.assertEqual(self.payments.refunded[order.charge.charge_id], order.charge.amount)
        self.assertEqual(self.stock.on_hand["lamp"], 3)
        self.assertEqual(sum(e.name == "OrderCancelled" for e in self.events.events.values()), 1)

    def test_checkout_rollback_reconciles_before_new_attempt(self):
        self.shipping.fail_dispatch = True
        self.payments.fail_after_refund = True
        with self.assertRaises(CompensationFailure):
            self.service.checkout(self.request)
        charge = next(iter(self.payments.charges.values()))
        self.assertEqual(self.payments.refunded[charge.charge_id], charge.amount)
        self.payments.unknown_refunds.add("buy:attempt:1:rollback")
        with self.assertRaises(CompensationFailure) as failure:
            self.service.checkout(self.request)
        self.assertIsInstance(failure.exception.errors[0], RefundUnresolved)
        self.assertEqual(len(self.payments.charges), 1)
        with self.assertRaises(IdempotencyConflict):
            self.service.checkout(CheckoutRequest("buy", "customer", (RequestedLine("lamp", 1),), "address", "token"))
        self.payments.unknown_refunds.clear()
        self.shipping.fail_dispatch = False
        order = self.service.checkout(self.request)
        self.assertEqual(len(self.payments.charges), 2)
        self.assertEqual(self.payments.refunded[charge.charge_id], charge.amount)
        self.assertEqual(self.payments.refunded[order.charge.charge_id], Decimal("0.00"))
        self.assertEqual(self.stock.on_hand["lamp"], 1)


if __name__ == "__main__":
    unittest.main()
