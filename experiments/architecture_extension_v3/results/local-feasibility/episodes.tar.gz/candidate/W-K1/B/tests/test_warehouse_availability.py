"""Availability affects new reservations without rewriting completed fulfilment."""

import json
import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, InMemoryEventSink, InMemoryOrderStore,
    InMemoryPayments, InMemoryPricing, InMemoryShipping, InMemoryStock,
    OutOfStock, RequestedLine,
)


class WarehouseAvailabilityTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock(
            {"north": {"lamp": 2}, "south": {"lamp": 2}, "east": {"lamp": 3}},
            priorities=("north", "south", "east"),
        )
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(
            InMemoryPricing({"lamp": Decimal("10.00")}), self.stock,
            self.payments, self.shipping, self.orders, self.events,
        )

    def request(self, key, quantity):
        return CheckoutRequest(
            key, "customer", (RequestedLine("lamp", quantity),), "10 Test Street", "token",
        )

    def test_closed_warehouse_is_skipped_and_reopening_affects_later_orders(self):
        self.stock.set_warehouse_open("north", False)
        order = self.service.checkout(self.request("first", 3))
        self.assertEqual([(a.warehouse_id, a.quantity) for a in order.allocations],
                         [("south", 2), ("east", 1)])
        self.assertEqual([s.warehouse_id for s in order.shipments], ["south", "east"])
        self.assertEqual(len(self.payments.charges), 1)
        data = dict(next(iter(self.events.events.values())).data)
        self.assertEqual(json.loads(data["allocations"]), [
            {"warehouse_id": "south", "sku": "lamp", "quantity": 2},
            {"warehouse_id": "east", "sku": "lamp", "quantity": 1},
        ])
        before = order.allocations, order.shipments, order.charge
        self.stock.set_warehouse_open("north", True)
        self.assertIs(self.service.checkout(self.request("first", 3)), order)
        self.assertEqual((order.allocations, order.shipments, order.charge), before)
        self.assertEqual(len(self.payments.charges), 1)
        later = self.service.checkout(self.request("later", 2))
        self.assertEqual([(a.warehouse_id, a.quantity) for a in later.allocations],
                         [("north", 2)])
        self.assertEqual(self.stock.on_hand["north"]["lamp"], 0)

    def test_shortage_with_closed_warehouse_has_no_checkout_effects(self):
        self.stock.set_warehouse_open("north", False)
        self.stock.set_warehouse_open("east", False)
        before = {name: dict(stock) for name, stock in self.stock.on_hand.items()}
        with self.assertRaises(OutOfStock):
            self.service.checkout(self.request("short", 3))
        self.assertEqual(self.stock.on_hand, before)
        self.assertFalse(self.stock.reservations)
        self.assertFalse(self.payments.charges)
        self.assertFalse(self.shipping.shipments)
        self.assertFalse(self.orders.orders)
        self.assertFalse(self.orders.pending_events())
        self.assertFalse(self.events.events)
        self.stock.set_warehouse_open("east", True)
        self.assertEqual([a.warehouse_id for a in self.service.checkout(
            self.request("short", 3)).allocations], ["south", "east"])

    def test_unknown_warehouse_is_rejected_and_flat_inventory_can_close(self):
        with self.assertRaises(ValueError):
            self.stock.set_warehouse_open("missing", False)
        flat = InMemoryStock({"lamp": 2})
        flat.set_warehouse_open("main", False)
        with self.assertRaises(OutOfStock):
            flat.reserve((RequestedLine("lamp", 1),), "flat")
        self.assertEqual(flat.on_hand, {"lamp": 2})
        flat.set_warehouse_open("main", True)
        self.assertEqual(flat.reserve((RequestedLine("lamp", 1),), "flat").allocations[0].warehouse_id,
                         "main")


if __name__ == "__main__":
    unittest.main()
