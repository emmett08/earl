"""Carrier rejection can reallocate reserved units without changing the purchase."""

import json
import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, InMemoryEventSink, InMemoryOrderStore,
    InMemoryPayments, InMemoryPricing, InMemoryShipping, InMemoryStock,
    OutOfStock, RequestedLine,
)


class CarrierSubstitutionTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock(
            {"north": {"lamp": 2}, "south": {"lamp": 2}, "east": {"lamp": 3}},
            priorities=("north", "south", "east"),
        )
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(
            InMemoryPricing({"lamp": Decimal("10.00")}), self.stock,
            self.payments, self.shipping, self.orders, self.events,
        )

    def request(self, key="request"):
        return CheckoutRequest(key, "customer", (RequestedLine("lamp", 3),), "street", "token")

    def test_rejected_source_is_replaced_in_order_and_event(self):
        self.shipping.reject_warehouses.add("north")
        order = self.service.checkout(self.request())
        self.assertEqual([(a.warehouse_id, a.quantity) for a in order.allocations],
                         [("south", 2), ("east", 1)])
        self.assertEqual([s.warehouse_id for s in order.shipments], ["south", "east"])
        self.assertEqual(self.stock.on_hand, {
            "north": {"lamp": 2}, "south": {"lamp": 0}, "east": {"lamp": 2},
        })
        self.assertEqual(order.quote.lines[0].quantity, 3)
        self.assertEqual(order.charge.amount, Decimal("36.00"))
        self.assertEqual(len(self.payments.charges), 1)
        data = dict(next(iter(self.events.events.values())).data)
        self.assertEqual([a["warehouse_id"] for a in json.loads(data["allocations"])],
                         ["south", "east"])
        self.assertEqual([s["warehouse_id"] for s in json.loads(data["shipments"])],
                         ["south", "east"])
        attempts = self.shipping.shipment_attempts
        self.assertIs(self.service.checkout(self.request()), order)
        self.assertEqual(self.shipping.shipment_attempts, attempts)

    def test_shortage_compensates_partial_receipt_and_retry_succeeds(self):
        self.shipping.reject_warehouses.add("south")
        self.stock.set_warehouse_open("east", False)
        original_stock = {name: dict(stock) for name, stock in self.stock.on_hand.items()}
        with self.assertRaises(OutOfStock):
            self.service.checkout(self.request())
        self.assertEqual(self.shipping.cancelled, set(self.shipping.shipments))
        self.assertEqual(self.stock.on_hand, original_stock)
        self.assertFalse(self.stock.reservations)
        charge = next(iter(self.payments.charges.values()))
        self.assertEqual(self.payments.refunded[charge.charge_id], charge.amount)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertFalse(self.orders.orders)
        self.assertFalse(self.orders.pending_events())
        self.assertFalse(self.events.events)
        self.shipping.reject_warehouses.clear()
        order = self.service.checkout(self.request())
        self.assertEqual([s.warehouse_id for s in order.shipments], ["north", "south"])
        self.assertEqual(len(self.payments.charges), 2)

    def test_closed_alternative_is_skipped_and_event_retry_does_not_dispatch(self):
        self.shipping.reject_warehouses.add("north")
        self.stock.set_warehouse_open("south", False)
        self.events.fail_publish = True
        order = self.service.checkout(self.request())
        self.assertEqual([(a.warehouse_id, a.quantity) for a in order.allocations], [("east", 3)])
        attempts = self.shipping.shipment_attempts
        self.events.fail_publish = False
        self.assertIs(self.service.checkout(self.request()), order)
        self.assertEqual(self.shipping.shipment_attempts, attempts)
        self.assertEqual(len(self.events.events), 1)


if __name__ == "__main__":
    unittest.main()
