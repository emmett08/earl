"""Ordered, bounded retries across ordinary and rerouted purchases."""

import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, InMemoryEventSink, InMemoryOrderStore,
    InMemoryPayments, InMemoryPricing, InMemoryShipping, InMemoryStock,
    RequestedLine,
)


class BoundedEventDeliveryTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock(
            {"north": {"lamp": 10}, "south": {"lamp": 10}, "east": {"lamp": 10}},
            priorities=("north", "south", "east"),
        )
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(
            InMemoryPricing({"lamp": Decimal("10.00")}), self.stock,
            self.payments, self.shipping, self.orders, self.events,
        )

    def make_pending_orders(self):
        self.events.fail_publish = True
        result = []
        for number in range(5):
            if number == 0:
                self.stock.set_warehouse_open("north", False)
            else:
                self.stock.set_warehouse_open("north", True)
            if number == 1:
                self.shipping.reject_warehouses.add("north")
            else:
                self.shipping.reject_warehouses.clear()
            request = CheckoutRequest(
                f"request-{number}", "customer", (RequestedLine("lamp", 1),),
                "street", "token",
            )
            result.append(self.service.checkout(request))
        self.assertEqual(result[0].allocations[0].warehouse_id, "south")
        self.assertEqual(result[1].allocations[0].warehouse_id, "south")
        self.assertEqual(len(self.orders.pending_events()), 5)
        self.events.fail_publish = False
        return result

    def test_bounded_calls_preserve_recorded_order_without_refulfilment(self):
        orders = self.make_pending_orders()
        effects = (len(self.payments.charges), len(self.stock.reservations),
                   self.shipping.shipment_attempts)
        self.assertEqual([self.service.retry_events(2) for _ in range(4)], [2, 2, 1, 0])
        self.assertEqual([event.order_id for event in self.events.events.values()],
                         [order.order_id for order in orders])
        self.assertFalse(self.orders.pending_events())
        self.assertEqual((len(self.payments.charges), len(self.stock.reservations),
                          self.shipping.shipment_attempts), effects)
        self.assertEqual(self.service.retry_events(), 0)

    def test_invalid_limit_has_no_delivery_effect(self):
        orders = self.make_pending_orders()
        for limit in (0, -1, 1.5, "2", True, False):
            with self.subTest(limit=limit), self.assertRaises(ValueError):
                self.service.retry_events(limit)
            self.assertFalse(self.events.events)
            self.assertEqual(len(self.orders.pending_events()), len(orders))
        self.assertEqual(self.service.retry_events(), 5)

    def test_failure_retains_failed_event_and_later_events(self):
        orders = self.make_pending_orders()
        original_publish = self.events.publish
        failed_id = self.orders.pending_events()[2].event_id

        def fail_third(event):
            if event.event_id == failed_id:
                raise RuntimeError("delivery failed")
            original_publish(event)

        self.events.publish = fail_third
        self.assertEqual(self.service.retry_events(5), 2)
        self.assertEqual([event.order_id for event in self.orders.pending_events()],
                         [order.order_id for order in orders[2:]])
        self.events.publish = original_publish
        self.assertEqual(self.service.retry_events(2), 2)
        self.assertEqual(self.service.retry_events(2), 1)
        self.assertEqual([event.order_id for event in self.events.events.values()],
                         [order.order_id for order in orders])


if __name__ == "__main__":
    unittest.main()
