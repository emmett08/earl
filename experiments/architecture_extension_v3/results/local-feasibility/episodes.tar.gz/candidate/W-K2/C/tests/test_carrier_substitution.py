"""Carrier warehouse rejection replaces only the affected reserved units."""

import json
import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, InMemoryEventSink, InMemoryOrderStore,
    InMemoryPayments, InMemoryPricing, InMemoryShipping, InMemoryStock,
    OutOfStock, RequestedLine,
)


class CarrierSubstitutionTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock(
            {"north": {"lamp": 2}, "south": {"lamp": 2}, "east": {"lamp": 3}},
            priorities=("north", "south", "east"),
        )
        self.shipping = InMemoryShipping()
        self.payments = InMemoryPayments()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(
            InMemoryPricing({"lamp": Decimal("10.00")}), self.stock,
            self.payments, self.shipping, self.orders, self.events,
        )

    def request(self):
        return CheckoutRequest("buy", "customer", (RequestedLine("lamp", 3),), "Street", "token")

    def test_rejection_reallocates_and_event_retry_does_not_dispatch_again(self):
        self.shipping.reject_warehouses.add("north")
        self.events.fail_publish = True
        order = self.service.checkout(self.request())
        expected = [("south", 2), ("east", 1)]
        self.assertEqual([(a.warehouse_id, a.quantity) for a in order.allocations], expected)
        self.assertEqual([(s.warehouse_id, sum(a.quantity for a in s.allocations)) for s in order.shipments], expected)
        self.assertEqual(self.stock.on_hand, {"north": {"lamp": 2}, "south": {"lamp": 0}, "east": {"lamp": 2}})
        self.assertEqual(order.quote.lines[0].quantity, 3)
        self.assertEqual(order.charge.amount, order.quote.total)
        self.assertEqual(len(self.payments.charges), 1)
        data = dict(self.orders.pending_events()[0].data)
        self.assertEqual([(a["warehouse_id"], a["quantity"]) for a in json.loads(data["allocations"])], expected)
        self.assertEqual([s["warehouse_id"] for s in json.loads(data["shipments"])], ["south", "east"])
        attempts = self.shipping.shipment_attempts
        self.events.fail_publish = False
        self.assertIs(self.service.checkout(self.request()), order)
        self.assertEqual(self.shipping.shipment_attempts, attempts)
        self.assertEqual(len(self.events.events), 1)

    def test_shortage_compensates_and_retry_after_rejection_clears(self):
        self.shipping.reject_warehouses.add("south")
        self.stock.set_warehouse_open("east", False)
        before = {name: dict(counts) for name, counts in self.stock.on_hand.items()}
        with self.assertRaises(OutOfStock):
            self.service.checkout(self.request())
        self.assertEqual(self.shipping.cancelled, set(self.shipping.shipments))
        self.assertEqual(self.stock.on_hand, before)
        self.assertFalse(self.stock.reservations)
        charge = next(iter(self.payments.charges.values()))
        self.assertEqual(self.payments.refunded[charge.charge_id], charge.amount)
        self.assertEqual(len(self.payments.refunds), 1)
        self.assertFalse(self.orders.orders)
        self.assertFalse(self.orders.pending_events())
        self.assertFalse(self.events.events)
        self.shipping.reject_warehouses.clear()
        order = self.service.checkout(self.request())
        self.assertEqual([(a.warehouse_id, a.quantity) for a in order.allocations], [("north", 2), ("south", 1)])
        self.assertEqual(len(self.payments.charges), 2)


if __name__ == "__main__":
    unittest.main()
