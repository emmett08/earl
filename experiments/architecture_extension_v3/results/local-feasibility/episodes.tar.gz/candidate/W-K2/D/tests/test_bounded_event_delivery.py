"""Batch limits preserve the outbox's recorded order and checkout effects."""

import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, InMemoryEventSink, InMemoryOrderStore,
    InMemoryPayments, InMemoryPricing, InMemoryShipping, InMemoryStock, RequestedLine,
)


class BoundedEventDeliveryTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock(
            {"north": {"lamp": 2}, "south": {"lamp": 2}, "east": {"lamp": 3}},
            priorities=("north", "south", "east"),
        )
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(
            InMemoryPricing({"lamp": Decimal("10.00")}), self.stock,
            self.payments, self.shipping, self.orders, self.events,
        )

    def checkout(self, key):
        return self.service.checkout(CheckoutRequest(
            key, "customer", (RequestedLine("lamp", 1),), "Street", "token",
        ))

    def test_five_events_are_delivered_in_successive_batches(self):
        self.events.fail_publish = True
        orders = [self.checkout(f"order-{number}") for number in range(5)]
        expected = [order.order_id for order in orders]
        effects = (len(self.payments.captures), len(self.stock.reservations), self.shipping.shipment_attempts)

        for invalid in (0, -1, 1.5, "2", True):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                self.service.retry_events(invalid)
            self.assertEqual(len(self.events.events), 0)
        self.events.fail_publish = False
        for count, delivered in ((2, 2), (2, 4), (1, 5), (0, 5)):
            self.assertEqual(self.service.retry_events(max_events=2), count)
            self.assertEqual([event.order_id for event in self.events.events.values()], expected[:delivered])
        self.assertFalse(self.orders.pending_events())
        self.assertEqual((len(self.payments.captures), len(self.stock.reservations), self.shipping.shipment_attempts), effects)

    def test_failed_publication_retains_later_events_across_warehouse_changes(self):
        self.events.fail_publish = True
        first = self.checkout("ordinary")
        self.stock.set_warehouse_open("north", False)
        second = self.checkout("closed-north")
        self.shipping.reject_warehouses.add("south")
        third = self.checkout("substituted")
        self.assertEqual([a.warehouse_id for a in second.allocations], ["south"])
        self.assertEqual([a.warehouse_id for a in third.allocations], ["east"])
        effects = (len(self.payments.captures), len(self.stock.reservations), self.shipping.shipment_attempts)

        self.events.fail_publish = False
        publish = self.events.publish
        def fail_second(event):
            if event.order_id == second.order_id:
                raise RuntimeError("temporary sink failure")
            publish(event)
        self.events.publish = fail_second
        self.assertEqual(self.service.retry_events(max_events=3), 1)
        self.assertEqual([event.order_id for event in self.orders.pending_events()], [second.order_id, third.order_id])
        self.events.publish = publish
        self.assertEqual(self.service.retry_events(max_events=1), 1)
        self.assertEqual(self.service.retry_events(max_events=1), 1)
        self.assertEqual(self.service.retry_events(max_events=1), 0)
        self.assertEqual([event.order_id for event in self.events.events.values()],
                         [first.order_id, second.order_id, third.order_id])
        self.assertEqual((len(self.payments.captures), len(self.stock.reservations), self.shipping.shipment_attempts), effects)


if __name__ == "__main__":
    unittest.main()
