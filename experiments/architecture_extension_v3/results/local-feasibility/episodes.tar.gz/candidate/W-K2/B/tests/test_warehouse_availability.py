"""Current warehouse availability affects only new reservations."""

import json
import unittest
from decimal import Decimal

from fulfilment import (
    CheckoutRequest, CheckoutService, InMemoryEventSink, InMemoryOrderStore,
    InMemoryPayments, InMemoryPricing, InMemoryShipping, InMemoryStock,
    OutOfStock, RequestedLine,
)


class WarehouseAvailabilityTest(unittest.TestCase):
    def setUp(self):
        self.stock = InMemoryStock(
            {"north": {"lamp": 2}, "south": {"lamp": 2}, "east": {"lamp": 3}},
            priorities=("north", "south", "east"),
        )
        self.payments = InMemoryPayments()
        self.shipping = InMemoryShipping()
        self.orders = InMemoryOrderStore()
        self.events = InMemoryEventSink()
        self.service = CheckoutService(
            InMemoryPricing({"lamp": Decimal("10.00")}), self.stock,
            self.payments, self.shipping, self.orders, self.events,
        )

    def request(self, key, quantity):
        return CheckoutRequest(key, "customer", (RequestedLine("lamp", quantity),), "Street", "token")

    def test_closed_warehouse_is_skipped_and_event_records_actual_sources(self):
        self.stock.set_warehouse_open("north", False)
        order = self.service.checkout(self.request("first", 3))
        expected = [("south", 2), ("east", 1)]
        self.assertEqual([(a.warehouse_id, a.quantity) for a in order.allocations], expected)
        self.assertEqual([(s.warehouse_id, sum(a.quantity for a in s.allocations)) for s in order.shipments], expected)
        self.assertEqual(self.stock.on_hand["north"]["lamp"], 2)
        self.assertEqual(len(self.payments.charges), 1)
        event_data = dict(next(iter(self.events.events.values())).data)
        self.assertEqual([(a["warehouse_id"], a["quantity"]) for a in json.loads(event_data["allocations"])], expected)

        self.stock.set_warehouse_open("north", True)
        later = self.service.checkout(self.request("second", 2))
        self.assertEqual([(a.warehouse_id, a.quantity) for a in later.allocations], [("north", 2)])
        self.assertEqual([(a.warehouse_id, a.quantity) for a in order.allocations], expected)
        self.assertEqual([s.warehouse_id for s in order.shipments], ["south", "east"])
        self.assertIs(self.service.checkout(self.request("first", 3)), order)
        self.assertEqual(len(self.payments.charges), 2)

    def test_shortage_in_open_warehouses_has_no_effects_and_can_retry_after_reopening(self):
        self.stock.set_warehouse_open("north", False)
        self.stock.set_warehouse_open("east", False)
        before = {name: dict(stock) for name, stock in self.stock.on_hand.items()}
        with self.assertRaises(OutOfStock):
            self.service.checkout(self.request("first", 3))
        self.assertEqual(self.stock.on_hand, before)
        self.assertFalse(self.stock.reservations)
        self.assertFalse(self.payments.charges)
        self.assertFalse(self.shipping.shipments)
        self.assertFalse(self.orders.orders)
        self.assertFalse(self.orders.pending_events())
        self.assertFalse(self.events.events)

        self.stock.set_warehouse_open("north", True)
        order = self.service.checkout(self.request("first", 3))
        self.assertEqual([(a.warehouse_id, a.quantity) for a in order.allocations], [("north", 2), ("south", 1)])

    def test_unknown_warehouse_is_rejected_without_changing_availability(self):
        with self.assertRaises(ValueError):
            self.stock.set_warehouse_open("missing", False)
        self.assertTrue(all(self.stock.warehouse_open.values()))


if __name__ == "__main__":
    unittest.main()
