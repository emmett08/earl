{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": null,
  "observed_at": null,
  "explanation": "The inspection_defects fact indicates deficiencies (value 1), which fails the requirement for zero defects within the past 5 minutes. Furthermore, the torque_verified fact is invalidated (false), breaching the verification requirement. Although serial_registered is true, the unresolved defect and invalid torque verification mean assembly is not ready to handoff.",
  "files": []
}