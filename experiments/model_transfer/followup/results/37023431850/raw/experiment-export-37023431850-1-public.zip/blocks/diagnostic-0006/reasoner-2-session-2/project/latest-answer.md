{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "The online restore seconds is within the maximum allowed 180 seconds, and both digest matches are confirmed, satisfying the primary route requirements. Archive available is false, so archive digest matching is not applicable for primary, but the primary criteria are met, making the route ready.",
  "files": []
}