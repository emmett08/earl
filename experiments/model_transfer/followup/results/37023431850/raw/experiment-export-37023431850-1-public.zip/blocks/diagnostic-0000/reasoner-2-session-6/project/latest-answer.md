{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 90,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "The latency measurement is below the 120 ms threshold, and rollback has been tested with approval granted, satisfying all criteria for release readiness. All facts are within the required age window.",
  "files": []
}