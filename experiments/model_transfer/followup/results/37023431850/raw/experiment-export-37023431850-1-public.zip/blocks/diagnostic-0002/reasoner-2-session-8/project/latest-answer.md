{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 50,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "Main response time exceeds the required threshold of 40ms (measured at 50ms). All other criteria are satisfied, but failure of this measurement prevents readiness.",
  "files": []
}