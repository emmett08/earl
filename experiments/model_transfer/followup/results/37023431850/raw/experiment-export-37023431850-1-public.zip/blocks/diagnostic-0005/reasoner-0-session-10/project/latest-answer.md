{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 210,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "All required facts meet the specified criteria: restore_seconds <= 180, digest_matches = true, and retention_confirmed = true, observed at 10:10, each within the last 5 minutes, confirming backup readiness.",
  "files": []
}