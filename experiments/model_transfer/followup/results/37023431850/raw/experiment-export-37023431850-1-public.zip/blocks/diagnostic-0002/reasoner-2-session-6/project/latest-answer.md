{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 35,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "Main response time is below 40 ms and main interlock passed; reserve is unavailable but its interlock passed, satisfying 'any_of' condition.",
  "files": []
}