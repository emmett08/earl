{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 150,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "Online restore seconds (150) exceeds the maximum allowed threshold of 180 seconds, preventing readiness under current criteria.",
  "files": []
}