{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 150,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "Restore duration (150 seconds) exceeds the maximum expected of 180 seconds; while other criteria are met, this alone prevents readiness.",
  "files": []
}