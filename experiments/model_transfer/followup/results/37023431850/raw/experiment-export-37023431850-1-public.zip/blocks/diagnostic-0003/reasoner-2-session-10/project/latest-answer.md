{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": {
    "replica_delay_ms": 10,
    "replica_authorised": true,
    "cache_available": false,
    "cache_authorised": true
  },
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "The measurement shows replica_delay_ms is 10 ms, which is less than the threshold of 15 ms; replica and cache are both authorized, although cache is currently unavailable, it does not affect the overall readiness under the 'any_of' rule since the replica requirement is satisfied. Both primary route requirements are met; hence, service is ready.",
  "files": []
}