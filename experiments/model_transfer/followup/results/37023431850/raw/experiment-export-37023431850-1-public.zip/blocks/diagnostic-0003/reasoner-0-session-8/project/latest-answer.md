{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": {
    "replica_delay_ms": 20,
    "replica_authorised": true,
    "cache_available": false,
    "cache_authorised": true
  },
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "The read path is considered ready under the reserve alternative, because cache is not available, which prevents primary route checks. The replica delay exceeds the primary criterion of ≤15 ms, but since cache is authorised and available, and replica is authorised, the reserve condition is met. The overall task is assessed as ready based on the 'any_of' logic.",
  "files": []
}