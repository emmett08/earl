{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 10,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "Both primary route requirements are satisfied: replica delay is at most 15 ms (actual 10 ms) and replica is authorized; cache is unavailable but cache authorization is confirmed. The alternative route criteria are also met, fulfilling the 'any_of' condition. No evidence indicates any conditions failing, and the measurement is current, confirming readiness.",
  "files": []
}