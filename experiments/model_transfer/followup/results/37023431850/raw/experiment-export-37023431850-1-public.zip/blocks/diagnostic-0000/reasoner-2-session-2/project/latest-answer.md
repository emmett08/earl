{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 90,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "The latest facts for the current version show latency of 90 ms (below 120 ms threshold), rollback tested true, and approval true, all within the last 5 minutes, fulfilling all evaluation criteria.",
  "files": []
}