{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": null,
  "observed_at": null,
  "explanation": "One or more required conditions are not clearly satisfied; validation errors, signature verification, and owner approval are assumed met based on current info, but measurement data specific to validation errors is missing or inconclusive, preventing full confirmation of readiness.",
  "files": []
}