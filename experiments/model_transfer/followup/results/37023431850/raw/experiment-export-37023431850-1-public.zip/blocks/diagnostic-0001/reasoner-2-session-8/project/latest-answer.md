{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 1,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "Validation errors are active (value: 1), indicating unresolved issues preventing publication readiness. Signature verification and owner approval are confirmed, but validation errors violate readiness criteria.",
  "files": []
}