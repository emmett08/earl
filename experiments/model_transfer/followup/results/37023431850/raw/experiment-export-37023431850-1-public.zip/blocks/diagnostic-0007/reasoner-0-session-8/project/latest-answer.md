{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 0,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "All critical inspection criteria are satisfied: zero defects observed within the last 5 minutes, torque verified, and serial registered. The snapshot confirms compliance with the assembly handoff requirements.",
  "files": []
}