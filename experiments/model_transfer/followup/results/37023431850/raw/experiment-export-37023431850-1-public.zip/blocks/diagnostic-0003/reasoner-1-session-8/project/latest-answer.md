{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 20,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "The replica_delay_ms exceeds the maximum allowed value of 15 milliseconds (measured at 20 ms). Additionally, cache is not available, failing one of the required conditions for readiness.",
  "files": []
}