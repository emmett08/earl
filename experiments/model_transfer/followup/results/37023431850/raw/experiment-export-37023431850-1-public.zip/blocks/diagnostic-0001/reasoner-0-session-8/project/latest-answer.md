{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 0,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "All validation requirements are satisfied: zero validation errors, signature verified, owner approved as per the latest measurement snapshot at 10:08 UTC.",
  "files": []
}