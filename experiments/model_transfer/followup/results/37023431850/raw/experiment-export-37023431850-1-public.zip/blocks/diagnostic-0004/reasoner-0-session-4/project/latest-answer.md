{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 120,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "The primary route has a delay exactly at the threshold of 120 milliseconds and is authenticated; fallback route is available and authenticated. Both alternative requirements are satisfied, indicating the routing is ready based on the current evidence snapshot.",
  "files": []
}