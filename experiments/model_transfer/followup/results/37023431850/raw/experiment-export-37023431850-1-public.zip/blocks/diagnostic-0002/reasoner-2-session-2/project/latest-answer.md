{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 35,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "Primary route requirement: main_response_ms is 35 ms, which is less than or equal to 40 ms, and main_interlock_passed is true. All conditions for primary route are satisfied. Reserve route requirements are not met as reserve_available is false.",
  "files": []
}