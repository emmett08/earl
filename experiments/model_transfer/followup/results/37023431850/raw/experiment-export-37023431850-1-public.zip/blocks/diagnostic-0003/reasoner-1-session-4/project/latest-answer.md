{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": {
    "replica_delay_ms": 10
  },
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "The replica delay (10 ms) is below the maximum threshold of 15 ms, and replica is authorized; however, the cache is not available (false), which fails the cache availability requirement. As at least one requirement in the 'any_of' condition is unmet, the overall assessment is not ready.",
  "files": []
}