{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "The primary route's delay of 150 milliseconds exceeds the threshold of 120 ms, but the fallback route is available and authenticated, fulfilling the alternative requirement set for routing readiness.",
  "files": []
}