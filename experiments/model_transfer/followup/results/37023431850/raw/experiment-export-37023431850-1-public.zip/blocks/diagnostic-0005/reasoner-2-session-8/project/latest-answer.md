{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 210,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "Restore seconds (210) exceeds the maximum acceptable threshold of 180 seconds specified in the criterion, indicating the backup is not yet ready. The other two criteria (digest matches and retention confirmed) are met.",
  "files": []
}