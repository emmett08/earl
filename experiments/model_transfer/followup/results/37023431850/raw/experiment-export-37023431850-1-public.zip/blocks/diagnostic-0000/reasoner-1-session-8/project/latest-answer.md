{
  "decision": "not_ready",
  "basis": "measurement_missing",
  "reading": null,
  "observed_at": null,
  "explanation": "The latency measurement for asset 'followup-all_of-release-missing' with version 'current-3' is missing or not within the required parameters. The latest available fact shows a latency of 150 ms, which exceeds the threshold of 120 ms. Additionally, the assessment window for recent data (max 5 minutes) has passed, and no recent acceptable measurement is available.",
  "files": []
}