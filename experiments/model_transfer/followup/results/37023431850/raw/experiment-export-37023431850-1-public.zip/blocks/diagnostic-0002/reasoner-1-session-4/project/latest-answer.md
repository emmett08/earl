{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 35,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "Main response time (35 ms) exceeds the required threshold; reserve system status (available: false) does not meet the required criteria.",
  "files": []
}