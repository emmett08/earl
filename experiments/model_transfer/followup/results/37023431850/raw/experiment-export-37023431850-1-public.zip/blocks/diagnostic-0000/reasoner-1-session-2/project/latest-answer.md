{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 90,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "Latency is below the 120 ms threshold; rollback tested and approval granted, all within the required time window.",
  "files": []
}