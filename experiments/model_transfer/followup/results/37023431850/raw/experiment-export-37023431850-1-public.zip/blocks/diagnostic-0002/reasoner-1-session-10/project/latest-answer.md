{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 35,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "The main_response_ms (35 ms) exceeds the maximum threshold of 40 ms required for primary route eligibility, disqualifying the system for immediate cooling activation. All interlock conditions are met, but the response time criterion has not been satisfied.",
  "files": []
}