{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 1,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "Inspection defects are non-zero (value: 1), which fails the requirement of zero defects. Torque verification and serial registration are both verified, but the defect count prevents readiness.",
  "files": []
}