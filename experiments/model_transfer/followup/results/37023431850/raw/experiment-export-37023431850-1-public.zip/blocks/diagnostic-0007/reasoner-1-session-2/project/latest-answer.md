{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": {
    "inspection_defects": 0,
    "torque_verified": true,
    "serial_registered": true
  },
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "All required criteria met within the specified time window; inspection defects are zero, torque verification and serial registration are confirmed.",
  "files": []
}