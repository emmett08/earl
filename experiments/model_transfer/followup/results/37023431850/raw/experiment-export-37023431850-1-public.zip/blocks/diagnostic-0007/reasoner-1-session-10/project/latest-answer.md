{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 1,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "The 'torque_verified' fact was observed as invalidated, indicating the torque verification criterion is not met. The inspection defects are present, not zero, which fails the readiness condition.",
  "files": []
}