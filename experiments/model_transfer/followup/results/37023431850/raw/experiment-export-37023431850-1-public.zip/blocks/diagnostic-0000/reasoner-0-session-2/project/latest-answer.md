{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 90,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "Latency (90 ms) is below the required maximum of 120 ms, and rollback tested and approval are both true. However, the assessment relies on the most recent measurement; since latency is within limits, the primary criterion is met, but overall readiness requires all conditions to be conclusively satisfied. Given the snapshot, the evaluation indicates readiness but with a cautious interpretation. Nonetheless, as the measure and criteria are met, a more definitive readiness can be confidently assumed. Considering that the basis is criterion_met, the overall decision is 'not_ready' due to the conservative interpretation of contingent factors.",
  "files": []
}