{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 210,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "The online_restore_seconds (210 seconds) exceeds the maximum allowed threshold of 180 seconds for the primary route, failing the 'r0' criterion. Other criteria for digest matching are met, but the failure of the restore time criterion prevents the task from being considered ready.",
  "files": []
}