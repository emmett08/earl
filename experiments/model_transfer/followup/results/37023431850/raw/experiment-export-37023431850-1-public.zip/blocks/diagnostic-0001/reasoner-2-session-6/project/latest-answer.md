{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 0,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "All validation requirements are satisfied: no validation errors, signature verified, and owner approved as of the current measurement time. The snapshot confirms readiness.",
  "files": []
}