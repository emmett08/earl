{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "All required facts—restore_seconds (150 <= 180), digest_matches (true), retention_confirmed (true)—are current and meet the specified criteria within the allowed age window. The measurement and facts are valid at the snapshot timestamp, fulfilling all conditions for readiness.",
  "files": []
}