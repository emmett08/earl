{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 210,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "The online restore time exceeds the maximum allowable 180 seconds for the primary route, failing the requirement. All other criteria are met.",
  "files": []
}