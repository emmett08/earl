{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "All required facts (restore_seconds = 150, digest_matches = true, retention_confirmed = true) are current, within the 5-minute window, and meet the specified criteria for backup readiness. The restore_seconds is less than or equal to 180, digest matches, and retention is confirmed, indicating the backup is ready.",
  "files": []
}