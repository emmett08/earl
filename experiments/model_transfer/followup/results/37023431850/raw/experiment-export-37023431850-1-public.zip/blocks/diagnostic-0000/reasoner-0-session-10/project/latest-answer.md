{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 150,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "Latency (150 ms) exceeds the maximum acceptable threshold of 120 ms as required. Approval and rollback tested statuses meet the criteria, but latency does not.",
  "files": []
}