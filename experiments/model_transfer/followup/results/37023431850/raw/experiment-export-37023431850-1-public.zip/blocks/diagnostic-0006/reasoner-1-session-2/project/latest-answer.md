{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "The online restore seconds fact indicates 150 seconds, which is less than the maximum threshold of 180 seconds, fulfilling the restore time criterion. Archive digest matches and online digest match are both true, meeting all required conditions for the primary route. Thus, the system is ready based on current measurements.",
  "files": []
}