{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 210,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "Restore seconds exceed the maximum allowed threshold of 180 seconds.",
  "files": []
}