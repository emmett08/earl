{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 0,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "All evaluation criteria are satisfied: zero validation errors, signature verified, owner approved, all within the required timeframe.",
  "files": []
}