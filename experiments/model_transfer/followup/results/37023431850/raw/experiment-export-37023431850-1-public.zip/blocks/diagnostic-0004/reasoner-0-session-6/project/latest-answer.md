{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 90,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "The primary route delay (90ms) exceeds the maximum allowable delay of 120ms for readiness, despite primary being authenticated. All other criteria are met; the delay criterion failed.",
  "files": []
}