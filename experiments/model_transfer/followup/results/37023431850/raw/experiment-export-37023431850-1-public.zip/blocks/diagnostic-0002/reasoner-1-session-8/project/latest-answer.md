{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 50,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "The main_response_ms measurement exceeds the maximum acceptable value of 40 ms, which prevents the cooling system from being considered ready according to the criteria.",
  "files": []
}