{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 0,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "Validation errors are present (value: 0), indicating unresolved issues, thus the publication is not yet ready for release.",
  "files": []
}