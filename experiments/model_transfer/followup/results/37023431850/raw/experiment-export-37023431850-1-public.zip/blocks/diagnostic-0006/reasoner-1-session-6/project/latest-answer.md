{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "The measured online_restore_seconds is 150, which is less than or equal to the threshold of 180 seconds, and both archive available and archive digest match facts are true within the required age limits, satisfying primary route conditions.",
  "files": []
}