{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "All active facts meet the required criteria: restore_seconds <= 180, digest matches, and retention is confirmed as of the snapshot time. The restore_seconds value is 150, which is below the threshold; digest_matches and retention_confirmed are true. Therefore, the backup is considered ready.",
  "files": []
}