{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 10,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "The measured replica_delay_ms (10 ms) is less than or equal to 15 ms and both replica_authorised and cache_authorised are true, satisfying the primary alternative requirements of the task rule.",
  "files": []
}