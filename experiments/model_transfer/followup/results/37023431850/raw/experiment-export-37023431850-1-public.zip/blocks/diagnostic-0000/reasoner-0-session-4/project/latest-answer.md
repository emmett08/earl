{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 115,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "All required facts are present and meet the specified criteria: latency is at most 120 ms, rollback has been tested, and approval is granted, all observed within the required time window.",
  "files": []
}