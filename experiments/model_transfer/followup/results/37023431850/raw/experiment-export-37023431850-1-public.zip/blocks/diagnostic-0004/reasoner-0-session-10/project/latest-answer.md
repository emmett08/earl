{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 90,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "The primary route's delay of 90 ms is within the acceptable threshold of 120 ms, and both primary authentication and fallback authentication are confirmed active at the snapshot time. Therefore, routing is ready based on current facts.",
  "files": []
}