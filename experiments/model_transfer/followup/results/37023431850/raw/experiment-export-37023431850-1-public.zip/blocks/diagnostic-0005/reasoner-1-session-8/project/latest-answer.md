{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 210,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "The restore_seconds measurement exceeds the maximum acceptable value of 180 seconds as per the requirement.",
  "files": []
}