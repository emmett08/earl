{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 0,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "All inspection criteria are satisfied: inspection defects are zero, torque has been verified, and serial registration is confirmed at the current timestamp.",
  "files": []
}