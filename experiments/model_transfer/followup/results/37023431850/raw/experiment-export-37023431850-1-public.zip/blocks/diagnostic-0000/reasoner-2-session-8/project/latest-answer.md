{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 150,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "The latency measurement exceeds the acceptable threshold of 120 ms (actual 150 ms).",
  "files": []
}