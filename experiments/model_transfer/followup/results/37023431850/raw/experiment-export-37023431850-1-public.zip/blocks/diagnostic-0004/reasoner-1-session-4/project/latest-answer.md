{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 100,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "The primary route's delay exceeds the maximum allowable 120 milliseconds (measured at 100 ms, which is within limit), but the fallback is not available or authenticated according to the latest facts, so the routing is not fully ready under current criteria.",
  "files": []
}