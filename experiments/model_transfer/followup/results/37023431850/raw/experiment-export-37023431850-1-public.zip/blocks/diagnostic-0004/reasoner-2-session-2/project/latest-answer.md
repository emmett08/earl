{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 90,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "The current snapshot indicates that the primary route has a delay of 90 ms (<= 120 ms) and is authenticated, satisfying the primary route requirements. Fallback route information is available but not needed to determine readiness under the 'any_of' logic, which is satisfied by the primary route conditions. Therefore, the routing is considered ready.",
  "files": []
}