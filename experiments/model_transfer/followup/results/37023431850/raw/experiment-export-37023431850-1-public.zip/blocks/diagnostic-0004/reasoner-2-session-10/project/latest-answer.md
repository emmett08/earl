{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": {
    "primary_delay_ms": 90
  },
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "The primary route delay is 90ms (less than 120ms) and both primary authentication and fallback authentication are confirmed true within the required recent timeframe, fulfilling the routing criteria.",
  "files": []
}