{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "All backup criteria are satisfied: restore_seconds is at most 180 (actual 150), digest_matches is true, and retention_confirmed is true at the specified timestamp, fulfilling the 'all_of' rule.",
  "files": []
}