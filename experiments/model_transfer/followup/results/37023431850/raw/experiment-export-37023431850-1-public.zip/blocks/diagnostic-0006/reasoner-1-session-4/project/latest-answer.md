{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "The online restore seconds is within the required 180 seconds limit and the digest matches; archive availability and digest match are confirmed, meeting primary route criteria.",
  "files": []
}