{
  "decision": "not_ready",
  "basis": "measurement_missing",
  "reading": null,
  "observed_at": null,
  "explanation": "At 10:08 UTC, the required facts for primary delay and authentication are either missing or not within the specified age window; fallback route facts are unavailable, preventing confirmation of routing readiness.",
  "files": []
}