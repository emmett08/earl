{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 1,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "Validation errors are active (value 1), violating the criterion of zero errors. Signature verification and owner approval are confirmed, but the presence of validation errors prevents readiness.",
  "files": []
}