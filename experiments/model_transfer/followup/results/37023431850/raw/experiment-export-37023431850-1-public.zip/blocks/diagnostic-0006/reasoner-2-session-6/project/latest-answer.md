{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "The online restore duration is within the maximum allowed of 180 seconds, and both online digest match and archive digest match are confirmed, satisfying primary route requirements.",
  "files": []
}