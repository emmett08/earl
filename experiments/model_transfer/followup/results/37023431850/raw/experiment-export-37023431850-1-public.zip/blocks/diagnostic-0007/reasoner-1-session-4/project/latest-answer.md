{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 0,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "The 'torque_verified' fact is active and true, and 'serial_registered' is active and true; 'inspection_defects' is invalidated and marked as 0. Since inspection defects are invalidated, the criterion for zero defects cannot be confirmed as met, leading to a 'not_ready' status.",
  "files": []
}