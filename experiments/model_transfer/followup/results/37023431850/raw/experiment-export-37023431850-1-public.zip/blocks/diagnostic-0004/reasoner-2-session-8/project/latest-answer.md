{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 150,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "The primary delay exceeds the threshold of 120 ms (measured at 150 ms), despite primary authentication being true, while fallback is unavailable. This failure to meet the delay criterion means routing is not ready.",
  "files": []
}