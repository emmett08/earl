{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 50,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "Main response time exceeds the maximum acceptable threshold of 40ms, failing the primary requirement for cooling activation readiness.",
  "files": []
}