{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 0,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "All validation criteria are satisfied: validation errors are zero, the signature is verified, and owner approval is confirmed as of the current timestamp.",
  "files": []
}