{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 0,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "All required conditions are satisfied: validation errors are zero, signature verified, and owner approved at the current snapshot.",
  "files": []
}