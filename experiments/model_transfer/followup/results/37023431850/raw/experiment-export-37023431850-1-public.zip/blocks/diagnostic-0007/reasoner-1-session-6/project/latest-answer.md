{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 0,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "All inspection criteria are satisfied: no inspection defects, torque verified, and serial registered, within the last 5 minutes.",
  "files": []
}