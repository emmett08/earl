{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "All active facts (restore_seconds=150, digest_matches=true, retention_confirmed=true) are within the required time window and meet the specified criteria for readiness. Since restore_seconds (150) is less than or equal to 180, and the other facts are true, the backup is ready.",
  "files": []
}