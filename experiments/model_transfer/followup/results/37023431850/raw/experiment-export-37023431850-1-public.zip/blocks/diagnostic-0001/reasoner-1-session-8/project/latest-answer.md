{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 1,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "Validation errors are active (value: 1), indicating the export has issues; despite signature verified and owner approved flags being true, the presence of validation errors prevents readiness.",
  "files": []
}