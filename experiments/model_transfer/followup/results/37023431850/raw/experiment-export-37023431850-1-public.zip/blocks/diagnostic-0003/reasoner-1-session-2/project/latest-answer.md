{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 10,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "The primary alternative requirements are satisfied: replica delay is 10 ms (<=15 ms), replica is authorized (true), cache is available (false but cache_authorized is true, which makes the second alternative true). The second (reserve) alternative's cache being unavailable, while potentially an issue, does not prevent the primary alternative from meeting the criteria. Therefore, the system is considered ready based on the active facts at the snapshot time.",
  "files": []
}