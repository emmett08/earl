{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 0,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "The measurement for 'rollback_tested' and 'approval' are both active and true, which satisfies two of the three criteria. However, the latency_ms reading is missing, preventing confirmation that it is at most 120 ms. Thus, not all criteria are met simultaneously.",
  "files": []
}