{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "At observed time, online_restore_seconds is 150 seconds (<=180), online_digest_matches is true, archive_available is false, but archive_digest_matches is true. The primary route's requirements for restore time and digest match are satisfied, making the route ready.",
  "files": []
}