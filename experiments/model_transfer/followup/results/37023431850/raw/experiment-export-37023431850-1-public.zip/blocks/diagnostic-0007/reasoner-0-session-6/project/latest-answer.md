{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 0,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "All inspection criteria are met: zero defects observed, torque verification confirmed, and serial registered within the required timeframe.",
  "files": []
}