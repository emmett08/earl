{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 150,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "Latency exceeds the maximum threshold of 120 ms (measured at 150 ms). All other requirements (rollback tested and approval granted) are satisfied but the latency criterion has not been met, so the task is not ready.",
  "files": []
}