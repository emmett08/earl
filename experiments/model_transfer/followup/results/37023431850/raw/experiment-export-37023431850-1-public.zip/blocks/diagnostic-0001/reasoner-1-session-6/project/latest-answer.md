{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 0,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "All required validation criteria are met: validation errors are zero, signature verified, and owner approved as of the latest snapshot at 10:06 UTC.",
  "files": []
}