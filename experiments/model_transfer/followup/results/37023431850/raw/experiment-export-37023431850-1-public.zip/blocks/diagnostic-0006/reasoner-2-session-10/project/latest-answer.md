{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "Online restore seconds are ≤180 and online digest matches, meeting primary route criteria. Archive available is false, but archive digest matches are true. Alternative route is satisfied by primary criteria, indicating restore readiness.",
  "files": []
}