{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 0,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "All validation errors are zero, signature verification is confirmed, and owner approval is active as of the current timestamp. The criteria for publication readiness are fully satisfied.",
  "files": []
}