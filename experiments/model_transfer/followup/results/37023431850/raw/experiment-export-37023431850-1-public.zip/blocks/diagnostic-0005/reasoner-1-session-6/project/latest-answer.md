{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "All backup criteria are satisfied: restore seconds <= 180, digest matches, and retention is confirmed, based on the latest facts within the required age.",
  "files": []
}