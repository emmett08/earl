{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 1,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "Inspection defects are active (value: 1), failing the requirement of zero defects; torque verify and serial registration are valid. The presence of defects prevents assembly handoff.",
  "files": []
}