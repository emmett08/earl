{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": {
    "replica_delay_ms": 10
  },
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "All required conditions are satisfied: replica delay is at most 15 ms, and both replica and cache are authorized and available. The observed facts meet the primary alternative criteria.",
  "files": []
}