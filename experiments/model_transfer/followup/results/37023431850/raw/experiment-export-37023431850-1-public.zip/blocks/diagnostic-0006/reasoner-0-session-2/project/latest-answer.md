{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "The online_restore_seconds is within the 180 seconds limit, and both online_digest_matches and archive_digest_matches are true, satisfying primary route requirements.",
  "files": []
}