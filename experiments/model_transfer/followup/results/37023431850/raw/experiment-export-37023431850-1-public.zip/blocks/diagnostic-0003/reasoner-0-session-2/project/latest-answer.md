{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 10,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "The facts indicate the replica delay is 10ms (<=15ms), and both replica and cache are authorized; all required conditions for the primary route are satisfied.",
  "files": []
}