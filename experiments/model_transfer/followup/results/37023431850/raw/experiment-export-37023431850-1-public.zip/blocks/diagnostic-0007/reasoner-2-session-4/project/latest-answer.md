{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 0,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "Inspection defects are invalidated (value: 0), which does not confirm zero defects. Torque verification and serial registration are active but insufficient alone; defective inspection precludes readiness.",
  "files": []
}