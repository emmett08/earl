{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 0,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "Validation errors are zero, the signature has been verified, and owner approval is confirmed as of the current snapshot. All criteria are met for publishing.",
  "files": []
}