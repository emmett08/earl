{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 90,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "The primary delay is 90 ms, which is less than the 120 ms threshold, and primary authentication is confirmed true. Fallback route is not available, but its authentication is true, satisfying alternative conditions. Hence, the routing is ready based on the 'any_of' rule.",
  "files": []
}