{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 35,
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "The main response time (35 ms) is less than or equal to 40 ms and the main interlock is passed; the reserve is not available but since the primary criteria are met, the system is considered ready.",
  "files": []
}