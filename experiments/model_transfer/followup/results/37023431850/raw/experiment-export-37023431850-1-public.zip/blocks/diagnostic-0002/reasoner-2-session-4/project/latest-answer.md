{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 35,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "The main_response_ms measurement is below the required threshold of 40 ms, and all other required active facts are valid. Therefore, the primary route's criterion is not met.",
  "files": []
}