{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 210,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "Restore seconds (210) exceed the required maximum of 180 seconds; digest matches and retention confirmed are satisfactory.",
  "files": []
}