{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": {
    "replica_delay_ms": 10,
    "replica_authorised": true,
    "cache_available": false,
    "cache_authorised": true
  },
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "The replica delay is below the maximum threshold (15 ms), and replica is authorised; cache is not available but is authorised, fulfilling one of the OR conditions per the requirement. The no-cache condition does not prevent readiness as the alternative path is satisfied.",
  "files": []
}