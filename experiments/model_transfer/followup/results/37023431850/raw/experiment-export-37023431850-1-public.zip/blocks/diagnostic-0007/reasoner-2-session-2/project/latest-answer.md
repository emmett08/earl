{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": {
    "inspection_defects": 0,
    "torque_verified": true,
    "serial_registered": true
  },
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "All inspection criteria are satisfied: no defects detected, torque verified, and serial registered within the required time frame; the snapshot confirms compliance. The criteria met the conditions for assembly handoff at this timestamp.",
  "files": []
}