{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 150,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "Latency exceeds the maximum threshold of 120 ms; other criteria (rollback tested, approval) are met.",
  "files": []
}