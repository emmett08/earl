{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "measurement": {
    "inspection_defects": 1
  },
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "Inspection defects are active (value 1), which does not meet the requirement of zero defects (expected 0). Torque verified and serial registered facts are present and valid, but the defect criterion is not satisfied.",
  "files": []
}