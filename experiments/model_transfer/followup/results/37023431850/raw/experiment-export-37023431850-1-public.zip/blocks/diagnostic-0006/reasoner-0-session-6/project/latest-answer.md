{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "All required facts meet the specified conditions: online_restore_seconds ≤ 180 (actual 150), online_digest_matches = true, archive_available = false (acceptable for primary), archive_digest_matches = true. The online_restore_seconds value is recent and within the max age of 5 minutes; all other facts are current and satisfy requirements. Despite archive being unavailable, the primary route's criteria are fulfilled, confirming readiness.",
  "files": []
}