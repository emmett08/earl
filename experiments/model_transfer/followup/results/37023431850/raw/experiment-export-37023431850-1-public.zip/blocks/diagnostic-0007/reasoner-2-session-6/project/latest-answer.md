{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 0,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "All required inspection defects are zero, torque verified, and serial registered as of the snapshot time. The criteria are fully met, indicating assembly handoff is ready.",
  "files": []
}