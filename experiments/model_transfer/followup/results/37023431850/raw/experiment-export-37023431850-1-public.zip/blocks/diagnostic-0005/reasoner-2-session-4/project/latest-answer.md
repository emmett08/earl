{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "The restore_seconds measurement is 150 seconds, which is less than or equal to the maximum allowed 180 seconds. Digest matches and retention are confirmed, fulfilling all criteria for readiness.",
  "files": []
}