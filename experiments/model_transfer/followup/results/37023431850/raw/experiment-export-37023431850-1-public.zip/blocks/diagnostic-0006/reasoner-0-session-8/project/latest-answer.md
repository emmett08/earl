{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 210,
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "The online_restore_seconds fact is 210 seconds, which exceeds the 180 seconds threshold required for the primary route. However, the archive is unavailable, and the archive_digest_matches fact is true, meeting the alternative criteria. Since the archive route is available and its digest matches, the restore is considered ready.",
  "files": []
}