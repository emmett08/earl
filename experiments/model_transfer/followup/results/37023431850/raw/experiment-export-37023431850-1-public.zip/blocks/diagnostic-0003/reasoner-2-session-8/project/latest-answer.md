{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": {
    "replica_delay_ms": 20
  },
  "observed_at": "2026-09-28T10:08:00Z",
  "explanation": "The replica delay is 20ms, which exceeds the required maximum of 15ms for readiness; other criteria are met.",
  "files": []
}