{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": 113,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "Primary route delay of 113 ms is below the 120 ms threshold, and primary authentication is confirmed. However, fallback route availability and fallback authentication are not confirmed, so the fallback alternative criteria are not met. Therefore, the routing cannot be considered fully ready based on configured criteria.",
  "files": []
}