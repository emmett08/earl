{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 90,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "The measured latency (90ms) is below the 120ms threshold, and rollback has been tested and approved as of the snapshot time. All criteria are met for task readiness.",
  "files": []
}