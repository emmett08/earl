{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "The online restore time is within 180 seconds, the online digest matches, archive is not available, but archive digest matches. Since the primary requirements for the restore route are met, the task is considered ready based on current evidence.",
  "files": []
}