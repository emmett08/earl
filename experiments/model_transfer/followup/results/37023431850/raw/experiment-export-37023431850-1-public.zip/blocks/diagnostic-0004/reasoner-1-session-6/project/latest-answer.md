{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 90,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "The primary route has a delay of 90ms, which is within the 120ms threshold, and is authenticated. The fallback route's availability and authentication status are not required for this path. All relevant criteria for a ready state are satisfied based on the latest snapshot.",
  "files": []
}