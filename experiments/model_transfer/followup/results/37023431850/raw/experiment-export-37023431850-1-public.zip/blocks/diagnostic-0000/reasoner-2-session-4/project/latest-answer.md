{
  "decision": "undetermined",
  "basis": "measurement_missing",
  "reading": null,
  "observed_at": null,
  "explanation": "No active measurement facts for latency, rollback tested, or approval within the required timeframe; unable to verify all criteria.",
  "files": []
}