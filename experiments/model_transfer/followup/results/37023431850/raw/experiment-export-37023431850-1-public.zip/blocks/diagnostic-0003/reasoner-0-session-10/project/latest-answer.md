{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 10,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "The active facts indicate the replica delay is 10 ms (<=15 ms) and replica is authorized; cache is unavailable but authorized. Given the rules are satisfied for at least one alternative (primary), the system is considered ready.",
  "files": []
}