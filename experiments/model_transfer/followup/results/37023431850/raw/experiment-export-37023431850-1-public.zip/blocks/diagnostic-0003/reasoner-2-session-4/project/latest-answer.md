{
  "decision": "not_ready",
  "basis": "criterion_failed",
  "reading": {
    "replica_delay_ms": 10
  },
  "observed_at": "2026-09-28T10:04:00Z",
  "explanation": "The replica delay of 10ms is below the maximum threshold of 15ms, and replica is authorized; however, cache is not available, which fails the 'any_of' read path criteria requiring either the replica conditions or the cache conditions to be fully met. Since the cache is unavailable and not authorized, the read path is not ready.",
  "files": []
}