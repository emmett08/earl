{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 90,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "The primary route has a delay of 90 ms (<= 120 ms) and is authenticated; fallback route availability and authentication are not relevant as primary route criteria are met.",
  "files": []
}