{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": {
    "replica_delay_ms": 10
  },
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "All necessary conditions are met: replica delay is below or equal to 15 ms, and both replica and cache are authorized and available. The latest facts confirm compliance within the required timeframe, indicating the read path is ready.",
  "files": []
}