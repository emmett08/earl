{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": {
    "primary_delay_ms": 90,
    "primary_authenticated": true,
    "fallback_available": false,
    "fallback_authenticated": true
  },
  "observed_at": "2026-09-28T10:02:00Z",
  "explanation": "The primary route has a delay of 90 ms (less than 120 ms) and is authenticated; fallback route is unavailable but fallback authenticated status is true, satisfying the routing criteria.",
  "files": []
}