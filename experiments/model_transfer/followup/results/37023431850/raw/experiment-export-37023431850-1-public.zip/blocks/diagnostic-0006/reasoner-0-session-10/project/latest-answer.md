{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:10:00Z",
  "explanation": "The conditions for the primary route are satisfied: online_restore_seconds (150s) is less than or equal to 180s, online_digest_matches is true, archive_available is false (acceptable since archive digest matches is true), but the essential criteria (online_restore_seconds and online_digest_matches) meet the required thresholds, making the primary route viable; the route therefore is considered ready based on current evidence.",
  "files": []
}