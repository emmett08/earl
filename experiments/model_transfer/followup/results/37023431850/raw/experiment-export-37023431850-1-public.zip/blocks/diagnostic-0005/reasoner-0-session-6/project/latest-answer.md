{
  "decision": "ready",
  "basis": "criterion_met",
  "reading": 150,
  "observed_at": "2026-09-28T10:06:00Z",
  "explanation": "All required facts—restore_seconds (150 <= 180), digest_matches (true), and retention_confirmed (true)—are present, active, and within the allowed age window (<=5 minutes). The snapshot confirms the backup is ready based on these criteria.",
  "files": []
}